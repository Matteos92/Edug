﻿using System.Collections.Generic;
using Windows.Networking.Connectivity;

namespace Edug
{
    class Classes
    {
        //klasa od dostepu do net
        public class Connection
        {
            public bool CheckInternetAccess()
            {
                var connectionProfile = NetworkInformation.GetInternetConnectionProfile();
                var HasInternetAccess = (connectionProfile != null && connectionProfile.GetNetworkConnectivityLevel() == NetworkConnectivityLevel.InternetAccess);
                return HasInternetAccess;
            }
        }

        public class RootObject
        {
            public UserLogin user_login { get; set; }
            public UserAccount user_account { get; set; }
            public List<ListGame> list_games { get; set; }
            public List<ListMission> list_missions { get; set; }
            public List<ExtraBadge> extra_badges { get; set; }
            public List<ListFile> list_files { get; set; }
            public List<ExtraAttendance> extra_attendances { get; set; }
            public MissionFast mission_fast { get; set; }
            public List<ExtraLeaderboard> extra_leaderboards { get; set; }
            public List<ExtraAchievement> extra_achievements { get; set; }
        }
        //dla MainPage
        public class ListGame
        {
            public Game game { get; set; }
        }

        public class Game
        {
            public string idg { get; set; }
            public string active { get; set; }
        }

        public class ListMission
        {
            public Mission mission { get; set; }
        }

        public class Mission
        {
            public string idm { get; set; }
            public string type { get; set; }
            public string start { get; set; }
            public string stop { get; set; }
            public string data { get; set; }
            public string codename { get; set; }
            public string points { get; set; }
        }

        public class UserLogin
        {
            public bool result { get; set; }
            public string comment { get; set; }
        }

        public class UserAccount
        {
            public bool result { get; set; }
            public string agent_number { get; set; }
            public string agent_name { get; set; }
            public string agent_email { get; set; }
            public int count_bitcoin { get; set; }
            public int count_avatar { get; set; }
            public int count_exacoin { get; set; }
            public int count_mission { get; set; }
            public int count_point { get; set; }
            public int count_badges_style { get; set; }
            public string lang { get; set; }
        }
        //dla odznak - deco
        public class Badge
        {
            public string name { get; set; }
            public string perc { get; set; }
            public string file { get; set; }
            public string desc { get; set; }
            public int valu { get; set; }
            public string see { get; set; }
        }

        public class ExtraBadge
        {
            public Badge badge { get; set; }
        }

        //dla filePage
        public class File
        {
            public string category { get; set; }
            public string filemane { get; set; }
            public string location { get; set; }
        }

        public class ListFile
        {
            public File file { get; set; }
        }
        //dla obecnosci
        public class ExtraAttendance
        {
            public Mission mission { get; set; }
        }

        //dla questionpage

        public class MissionFast
        {
            public bool result { get; set; }
            public string comment { get; set; }
            public string codename { get; set; }
            public object picture { get; set; }
            public string intro_time { get; set; }
            public string intro_text { get; set; }
            public string mission_file { get; set; }
            public string mission_start { get; set; }
            public string mission_text { get; set; }
            public string finish_time { get; set; }
            public string finish_text { get; set; }
            public string question_1 { get; set; }
            public string question_2 { get; set; }
            public string question_3 { get; set; }
            public string question_4 { get; set; }
            public string question { get; set; }
            public string mission { get; set; }
            public Answers1 answers_1 { get; set; }
            public Answers2 answers_2 { get; set; }
            public Answers3 answers_3 { get; set; }
            public Answers4 answers_4 { get; set; }
        }

        public class Answers1
        {
            public string _2 { get; set; }
            public string _1 { get; set; }
            public string _3 { get; set; }
            public string _4 { get; set; }
        }

        public class Answers2
        {
            public string _2 { get; set; }
            public string _1 { get; set; }
            public string _3 { get; set; }
            public string _4 { get; set; }
        }

        public class Answers3
        {
            public string _2 { get; set; }
            public string _1 { get; set; }
            public string _3 { get; set; }
            public string _4 { get; set; }
        }

        public class Answers4
        {
            public string _2 { get; set; }
            public string _1 { get; set; }
            public string _3 { get; set; }
            public string _4 { get; set; }
        }

        //dla RankPage
        public class Position
        {
            public string type { get; set; }
            public string idu { get; set; }
            public string email { get; set; }
            public string points { get; set; }
        }

        public class ExtraLeaderboard
        {
            public Position position { get; set; }
        }

        //dla ResultPage
        public class ExtraAchievement
        {
            public Mission mission { get; set; }
        }
    }
}
