﻿using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.Globalization;
using System.Net.Http;
using System.Text.RegularExpressions;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

namespace Edug
{

    public sealed partial class QuestionForLastPage : Page
    {
        public QuestionForLastPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            setLanguage();
            Functions.Function.getInfo();//funckja do aktualizacji informacji nt. zdobytych punktów przez agenta
            setAppBar();
            getQuestions(PassedData.urlForQuestion.ToString());
            PassedData.urlForQuestion = "";
        }

        public string login = PassedData.agent_email, pswrd = PassedData.pswrd, passs = PassedData.loginPassword, system = PassedData.system, lang = PassedData.lang, game = PassedData.group, sum, sumOdp, sum1;
        public string type = PassedData.missionType;
        public string optRequireString, needRequireString, orderString;

        public class MissionFast
        {
            public bool result { get; set; }
            public string comment { get; set; }
            public string codename { get; set; }
            public object picture { get; set; }
            public string intro_time { get; set; }
            public string intro_text { get; set; }
            public string mission_start { get; set; }
            public string mission_text { get; set; }
            public string finish_time { get; set; }
            public string finish_text { get; set; }
            public string question { get; set; }
            public string mission { get; set; }
            public string answers_1 { get; set; }
            public string answers_2 { get; set; }
            public string answers_3 { get; set; }
            public string answers_4 { get; set; }
        }

        public class RootObject
        {
            public MissionFast mission_fast { get; set; }
        }

        public void setAppBar()
        {
            AvatarAddAppBarButton.Label = PassedData.count_avatar + PassedData.countAvatarString;
            BitcoinAddAppBarButton.Label = PassedData.count_bitcoin + PassedData.countBitcoinString;
            ExacoinAddAppBarButton.Label = PassedData.count_exacoin + PassedData.countExacoinString;
            PointsAddAppBarButton.Label = PassedData.count_point + PassedData.countPointString;
        }

        public async void getQuestions(string url)
        {
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    Uri uri = new Uri(url);
                    client.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;
                    var Response = await client.GetAsync(uri);
                    var statusCode = Response.StatusCode;
                    Response.EnsureSuccessStatusCode();
                    var ResponseText = await Response.Content.ReadAsStringAsync();
                    client.CancelPendingRequests();
                    client.Dispose();
                    getQuestion(ResponseText);
                    ResponseText = null;
                    PassedData.urlForQuestion = null;
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
        }

        private void showLoading()
        {
            this.loadingView.Visibility = Visibility.Visible;
            this.imageSlot.Visibility = Visibility.Collapsed;
            this.errorView.Visibility = Visibility.Collapsed;
        }

        private void showError(string message)
        {
            this.loadingView.Visibility = Visibility.Collapsed;
            this.imageSlot.Visibility = Visibility.Collapsed;
            this.errorView.Visibility = Visibility.Visible;

            this.errorView.Text = message;
        }

        private void showImage()
        {
            this.loadingView.Visibility = Visibility.Collapsed;
            this.imageSlot.Visibility = Visibility.Visible;
            this.errorView.Visibility = Visibility.Collapsed;
        }

        public void getQuestion(string data)
        {
            String matchpattern = @"\<\w\w.\\\/\>";
            String replacementpattern = @"\n";
            data = Regex.Replace(data, matchpattern, replacementpattern);

            RootObject obj = JsonConvert.DeserializeObject<RootObject>(data);
            string result = obj.mission_fast.result.ToString();
            string comment = obj.mission_fast.comment;
            try
            {
                if (result == "True")
                {
                    string missionNumber = obj.mission_fast.mission;//numer misji!!!
                    PassedData.missionNumber = missionNumber;
                    string codename = obj.mission_fast.codename.ToString();//tytuł misji!!!
                    object picture = obj.mission_fast.picture;
                    string intro_text = obj.mission_fast.intro_text;
                    string question = obj.mission_fast.question;
                    string finish_text = obj.mission_fast.finish_text;
                    string answer11 = obj.mission_fast.answers_1.ToString();
                    string answer12 = obj.mission_fast.answers_2.ToString();
                    string answer13 = obj.mission_fast.answers_3.ToString();
                    string answer14 = obj.mission_fast.answers_4.ToString();
                   
                    codename = CultureInfo.CurrentCulture.TextInfo.ToUpper(codename);//n->N
                    numberText.Text = missionNumber;
                    codenameText.Text = codename;
                    startTimeText.Text = PassedData.startString;
                    finishTimeText.Text = PassedData.finishString;
                    Question1TextBlock.Text = question;
                    //----------------------------------------------
                    //spr wyswietlanie obrazku do pytania
                    if (picture == null|| picture.Equals(""))
                    {
                        imageSlot.Visibility = Visibility.Collapsed;
                    }
                    else
                    {
                        var bitmap = new BitmapImage(new Uri(picture.ToString()));
                        bitmap.ImageFailed += (s, e) => this.showError("Error while loading the image.");
                        bitmap.ImageOpened += (s, e) => this.showImage();
                        showLoading();
                        imageSlot.Source = bitmap;
                    }
                    Answer11.Text = answer11;
                    Answer12.Text = answer12;
                    Answer13.Text = answer13;
                    Answer14.Text = answer14;
                }
                else
                {
                    Functions.Function.showMessage(comment);
                    UpRow.Visibility = Visibility.Collapsed;
                    DownRow.Visibility = Visibility.Collapsed;
                    Frame.Navigate(typeof(MissionPage));
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
        }

        private void sendButton_Click(object sender, RoutedEventArgs e)
        {
            string missionToSend = PassedData.missionNumber;
            string type = PassedData.missionType;
            string answer1 = null;
            string url = null;
            String crcOdp = null;
            //------------------------------------------
            String hash = MD5CryptoServiceProvider.GetMd5String(passs);
            sum = pswrd + system + lang + game + missionToSend + login + hash;
            String crc = MD5CryptoServiceProvider.GetMd5String(sum);
            // BSIBSIwpplamw145tesmatgrauman@gmail.com5d61b33868329ec1d305daba428e2feb
            //-----------------------------
            if (CheckBox11.IsChecked == true)
            {
                answer1 += "1";
            }
            if (CheckBox12.IsChecked == true)
            {
                answer1 += "2";
            }
            if (CheckBox13.IsChecked == true)
            {
                answer1 += "3";
            }
            if (CheckBox14.IsChecked == true)
            {
                answer1 += "4";
            }
            if (answer1 == null)
            {
                Functions.Function.showMessage("Wybierz przed wysłaniem odpowiedzi");
            }
            else
            {
                sumOdp = pswrd + system + lang + game + missionToSend + answer1 + login + hash;
                crcOdp = MD5CryptoServiceProvider.GetMd5String(sumOdp);
                switch (type)
                {
                    case "hazd":
                        url = @"http://www.edug.pl/_webservices/mission_hazd.php?sys=" + system + "&lang=" + lang + "&game=" + game + "&mission=" + missionToSend + "&answer=" + answer1 + "&login=" + login + "&hash=" + hash + "&crc=" + crcOdp;
                        break;
                    case "last":
                        url = @"http://www.edug.pl/_webservices/mission_last.php?sys=" + system + "&lang=" + lang + "&game=" + game + "&mission=" + missionToSend + "&answer=" + answer1 + "&login=" + login + "&hash=" + hash + "&crc=" + crcOdp;
                        break;
                }
                sendAnswer(url);
            }
        }

        public async void sendAnswer(string url)
        {
            //do wyslania odp na serwer
            using (HttpClient client = new HttpClient())
            {
                var uri = new Uri(url);
                client.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;
                var Response = await client.GetAsync(uri);
                var statusCode = Response.StatusCode;
                Response.EnsureSuccessStatusCode();
                var ResponseText = await Response.Content.ReadAsStringAsync();
                Classes.RootObject obj = JsonConvert.DeserializeObject<Classes.RootObject>(ResponseText);
                string mess = obj.mission_fast.comment.ToString();
                Functions.Function.showMessage(mess);
                Frame.Navigate(typeof(MissionPage));
                PassedData.missionNumber = null;
            }
            //https:/ /stackoverflow.com/questions/21134380/no-cache-with-httpclient-in-windows-phone-8
        }

        public void setLanguage()
        {
            switch (PassedData.lang)
            {
                case "pl":
                    sendButton.Content = "ODPOWIEDŹ";
                    startTimeTextBlock.Text = "Start";
                    finishTimeTextBlock.Text = "Koniec";
                    optRequireString = "opcjonalna";
                    needRequireString = "obowiązkowa";
                    orderString = "losowa";
                    numberTextBlock.Text = "Numer";
                    codenameTextBlock.Text = "Kryptonim";
                    switch (type)
                    {
                        case "hazd":
                            missTextBlock.Text = "MISJA HAZARDOWA";
                            break;
                        case "last":
                            missTextBlock.Text = "MISJA OSTATECZNA";
                            break;
                    }
                    break;
                case "en":
                    sendButton.Content = "ANSWER";
                    startTimeTextBlock.Text = "Start";
                    finishTimeTextBlock.Text = "Finish";
                    optRequireString = "optional";
                    needRequireString = "obligatory";
                    orderString = "random";
                    numberTextBlock.Text = "Number";
                    codenameTextBlock.Text = "Codename";
                    switch (type)
                    {
                        case "hazd":
                            missTextBlock.Text = "HAZARD MISSION";
                            break;
                        case "last":
                            missTextBlock.Text = "FINAL MISSION";
                            break;
                    }
                    break;
            }
        }

        private void backButton_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(MissionPage));
        }

        private async void logoutButton_Click(object sender, RoutedEventArgs e)
        {

            MessageDialog messageDialog = new MessageDialog(PassedData.askString);
            messageDialog.Commands.Add(new UICommand(PassedData.yesString, new UICommandInvokedHandler(CommandInvokedHandler)));
            messageDialog.Commands.Add(new UICommand(PassedData.noString));

            // Set the command that will be invoked by default
            messageDialog.DefaultCommandIndex = 0;

            // Set the command to be invoked when escape is pressed
            messageDialog.CancelCommandIndex = 1;

            // Show the message dialog
            await messageDialog.ShowAsync();
        }

        public void CommandInvokedHandler(IUICommand command)
        {
            PassedData.startString = null;
            PassedData.finishString = null;
            PassedData.LogOut = true;
            PassedData.isSelected = false;
            PassedData.chosenComboItem = null;
            PassedData.chosenTheme = "1";
            Frame.Navigate(typeof(MainPage));
        }
    }
}

