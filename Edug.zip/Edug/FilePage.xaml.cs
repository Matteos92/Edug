﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace Edug
{

    public sealed partial class FilePage : Page
    {
        public FilePage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            setLanguage();
            Functions.Function.getInfo();//funckja do aktualizacji informacji nt. zdobytych punktów przez agenta
            setAppBar();
            getFiles();
        }

        public void setLanguage()//Ustawia wyświetlany tekst według języka
        {
            switch (PassedData.lang)
            {
                case "pl"://polski
                    BackButton.Label = "Powrót";
                    LogoutButton.Label = "Wyloguj";
                    pivot_specjal.Header = "Specjalny";
                    pivot_lab.Header = "Laboratoryjny";
                    pivot_doc.Header = "Dodatkowy";
                    BackButton.Label = "Powrót";
                    LogoutButton.Label = "Wyloguj";
                    break;
                case "en"://angielski
                    BackButton.Label = "Back";
                    LogoutButton.Label = "Log out";
                    pivot_specjal.Header = "Special";
                    pivot_lab.Header = "Lab";
                    pivot_doc.Header = "Additional";
                    BackButton.Label = "Back";
                    LogoutButton.Label = "Logout";
                    break;
            }
        }

        public void setAppBar()//Ustawia treść i wartość przycisków na belce na dolnej części ekranu
        {
            AvatarAddAppBarButton.Label = PassedData.count_avatar + PassedData.countAvatarString;//treść i wartość dla avatarów
            BitcoinAddAppBarButton.Label = PassedData.count_bitcoin + PassedData.countBitcoinString;//treść i wartość dla bitcoinów
            ExacoinAddAppBarButton.Label = PassedData.count_exacoin + PassedData.countExacoinString;//treść i wartość dla exacoinów
            PointsAddAppBarButton.Label = PassedData.count_point + PassedData.countPointString;//treść i wartość dla punktów
        }

        public async void getFiles()//Funkcja do pobrania informacji o plikach z serwera
        {
            try
            {
                //Utworzenie klienta http
                using (HttpClient client = new HttpClient())
                {
                    //Definiowanie URL
                    string link = @"https://www.edug.pl/_webservices/list_files.php?idg=amw145tes";
                    var uri = new Uri(link);
                    client.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;
                    //Wywołanie oraz pobranie asynchronicznie odpowiedzi 
                    var Response = await client.GetAsync(uri);
                    //Odpowiedź i kod statusu
                    var statusCode = Response.StatusCode;
                    //Jeśli kod statusu jest inny niż 200 wtedy proces EnsureSuccessStatusCode wyrzuci wyjątek 
                    Response.EnsureSuccessStatusCode();
                    //Czytanie zawartości odpowiedzi
                    //Tutaj spodziewaną odpowiedzią jest ciąg znaków
                    var ResponseText1 = await Response.Content.ReadAsStringAsync();
                    client.CancelPendingRequests();//anuluje wszystkie oczekujące żądania
                    client.Dispose();// zbywa zarządzane zasoby
                    getFilePath(ResponseText1);//wywołanie funkcji do obsługi zawartości odpowiedzi
                }
            }
            catch (Exception ex)//przy wychwyceniu wyjątku i jego wyświetlenie
            {
                Debug.WriteLine(ex);
            }
        }

        public string category, filemane, location;//Pomocnicze stringi

        public void getFilePath(string data)//Funkcja, gdzie do słownika jako klucz dodawany jest nazwa pliku, a wartość lokalizacja pliku
        {
            Classes.RootObject obj = JsonConvert.DeserializeObject<Classes.RootObject>(data);//zmienna gdzie konwertuje się zawartość odpowiedzi serwera z pliku .json
            int licznik = obj.list_files.Count;//liczba plików
            for (int i = 0; i < licznik; i++)
            {
                var item = new Classes.File();//tworzenie instancji klasy pliku
                category = obj.list_files[i].file.category;//kategoria
                filemane = obj.list_files[i].file.filemane;//nazwa pliku
                location = obj.list_files[i].file.location;//lokalizacja pliku do pobrania
                if (category == "spec")//gdy plik należy do kategorii "Specjalny"
                {
                    item.filemane = filemane;//pobranie nazwy pliku
                    location = location.Replace("'\'", "");//usunięcie ukośnika z nazwy
                    PassedData.slownik.Add(filemane, location);//dodanie do słownika nazwy pliku jako klucza i lokalizacji jako wartość
                    speclist.Items.Add(item);//dodanie do specjalnej dla tej kategorii listy plików do wyświetlenia
                }
                else if (category == "labo")//gdy plik należy do kategorii "Laboratoryjny"
                {
                    item.filemane = filemane;
                    location = location.Replace("'\'", "");
                    PassedData.slownik.Add(filemane, location);
                    lablist.Items.Add(item);
                }
                else//gdy plik należy do kategorii "Dodatkowy"
                {
                    item.filemane = filemane;
                    location = location.Replace("'\'", "");
                    PassedData.slownik.Add(filemane, location);
                    doclist.Items.Add(item);
                }
            }
        }

        private void list_SelectionChanged(object sender, SelectionChangedEventArgs e)//Funkcja do znalezienia lokalizacji pliku w słowniku dzięki nazwie pliku
        {
            Classes.File myobject = (sender as ListView).SelectedItem as Classes.File;
            if (myobject != null)
            {
                string value, key = myobject.filemane;
                if (PassedData.slownik.ContainsKey(key))//jeśli w słowniku jest dany klucz
                {
                    value = PassedData.slownik[key];//zwraca wartość
                    adresLink(value);
                }
            }
        }

        private async void adresLink(string uriToLaunch)//Funkcja do pobrania pliku z przeglądarki
        {
            await Windows.System.Launcher.LaunchUriAsync(new Uri(uriToLaunch));//przejście do przeglądarki z danym odnośnikiem do pliku
        }

        private void backButton_Click(object sender, RoutedEventArgs e)//Powrót do strony poprzedniej
        {
            PassedData.slownik.Clear();//wyczyszczenie zawartości słownika
            Frame.Navigate(typeof(MenuPage));//nastepnie powrót do strony poprzedniej
        }

        private async void logoutButton_Click(object sender, RoutedEventArgs e)//Funkcja po kliknięciu przycisku do wylogowania
        {

            MessageDialog messageDialog = new MessageDialog(PassedData.askString);//wyświetlenie treści komunikatu z pytaniem o wylogowanie się
            messageDialog.Commands.Add(new UICommand(PassedData.yesString, new UICommandInvokedHandler(CommandInvokedHandler)));//dodanie i obsługa przy kliknięciu potwierdzającego wylogowanie
            messageDialog.Commands.Add(new UICommand(PassedData.noString));//dodanie i obsługa przy kliknięciu anulującego wylogowanie

            //Ustawiona komenda, która będzie domyślnie wywoływana
            messageDialog.DefaultCommandIndex = 0;

            //Ustawione polecenie, które ma zostać wywołane po naciśnięciu klawisza escape
            messageDialog.CancelCommandIndex = 1;

            //Pokazanie okna z zapytaniem o wylogowanie się
            await messageDialog.ShowAsync();
        }

        public void CommandInvokedHandler(IUICommand command)//Wywoływana funkcja gdy użytkownik potwierdzi wylogowanie się z aplikacji
        {
            PassedData.slownik.Clear();//wyczyszczenie zawartości słownika
            PassedData.LogOut = true;//ustawienie flagi dla wylogowania użytkownika żeby wyświetlić komunikat o wylogowaniu się
            PassedData.isSelected = false;//ustawienie domyślnej wartości flagi wybranej pozycji z comboBoxa
            PassedData.chosenComboItem = null;//ustawienie domyślnej wartości zapamiętanej pozycji z comboBoxa
            PassedData.chosenTheme = "1";//ustawienie domyślnej wartości motywu
            Frame.Navigate(typeof(MainPage));//przeniesienie do strony logowania
        }
    }
}


