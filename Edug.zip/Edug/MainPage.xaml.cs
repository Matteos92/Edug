﻿using System;
using System.Diagnostics;
using System.Net.Http;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml.Input;
using Newtonsoft.Json;
using Windows.System;
using Windows.Storage;
using System.IO;
using System.Text.RegularExpressions;

namespace Edug
{
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)//Wywowyłana gdy strona stanie się aktywna
        {
            startApp();
        }

        public string one = "one", two = "two";//Pomocnicze stringi

        public void startApp()//Pierwsza metoda która uruchamia się po starcie aplikacji bądź wylogowaniu
        {
            try
            {
                if (PassedData.LogOut == true)//Po wylogowaniu
                {
                    Functions.Function.showMessage("Zostałeś wylogowany.\nYou have been logged out.");//Komunikat o wylogowaniu się
                    PassedData.LogOut = false;//Ustawienie flagi z wylogowaniu się
                    PassedData.group = null;//Wyczyszcza zapamiętaną grupę agenta
                    PassedData.login = null;//Wyczyszcza zapamiętany login agenta
                    PassedData.loginPassword = null;//Wyczyszcza zapamiętane hasło agenta
                    PassedData.isSelected = false;//Wyczyszcza zapamiętaną flagę dla wyboru motywu
                    PassedData.chosenComboItem = null;// Wyczyszcza zapamiętaną wartość motywu
                    PassedData.chosenTheme = "1";//Ustawia domyślny numer motywu
                    saveFile("false");//Nic nie zapisuje
                    string link = @"http://www.edug.pl/_webservices/list_games.php";//Adres url do pobrania listy grup
                    getList(one, link);//Pobranie listy grup
                }
                else
                {
                    loadFile();//Pobranie zapisanych danych żeby nie wpisywać ponownie danych do logowania
                } 
            }
            catch (HttpRequestException ex)
            {
                Functions.Function.showMessage("Brak dostępu do Internetu. Sprawdź połączenie.\nNo internet access. Check connection.");
                //Komunikat gdy pojawia się brak dostępu do Internetu
            }
        }

        private async void getList(string game, string link)//Pobranie odpowiedzi od serwera
        {
            try
            {
                //Tworzenie klienta http
                using (HttpClient client = new HttpClient())
                {
                    var uri = new Uri(link);//Definiowanie adresu URL
                    client.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;//Sprawdzenie czy zaszła zmiana od ostatniego żądania do serwera od momentu wysłania zapytania
                    // Wywołanie. Uzyskanie odpowiedzi asynchronicznie
                    var Response = await client.GetAsync(uri);
                    //Rezultat i kod
                    var statusCode = Response.StatusCode;
                    //Jeśli odpowiedź jest inna od Http 200
                    //wtedy metoda EnsureSuccessStatusCode wyrzuci wyjątek
                    Response.EnsureSuccessStatusCode();
                    //Odczyt zawartości odpowiedzi
                    //Spodziewana odpowiedź jest ciągiem znaków
                    //Odczyt zawartości za pomocą metody ReadAsStringAsync
                    var ResponseText1 = await Response.Content.ReadAsStringAsync();
                    client.CancelPendingRequests();//Anulowanie wszelkich żądań do webserwera
                    client.Dispose();//Zamknięcie klienta
                    switch (game)//W zależności od kategorii obsługi odpowiedzi od webserwera
                    {
                        case "one":
                            getGame(ResponseText1);//Przetworzenie i dodanie do kontrolki ComboBox listę aktywnych grup
                            break;

                        case "two":
                            getData(ResponseText1);//Sprawdzenie statusu logowania użytkownika
                            break;

                        default:
                            break;
                    }
                }
            }
            catch (HttpRequestException ex)//Przy pojawieniu się wyjątku z błędem o braku dostępu do Internetu wyświetla się komunikat
            {
                Functions.Function.showMessage("Brak dostępu do Internetu. Sprawdź połączenie.\nNo internet access. Check connection.");
            }
            catch (Exception ex)//Przy pojawieniu się innego wyjątku z błędem wyświetla się w konsoli, wyświetla się w konsoli treść błędu
            {
                Debug.WriteLine(ex.ToString());
            }
        }

        private void getGame(string game)//Przetworzenie i dodanie do kontrolki ComboBox listę aktywnych grup
        {
            try
            {
                var obj = JsonConvert.DeserializeObject<Classes.RootObject>(game);//zmienna gdzie konwertuje się zawartość odpowiedzi serwera z pliku .json 
                int licznik = obj.list_games.Count;// licznik wszystkich grup
                licznik = licznik - 1;
                for (int i = licznik; i >= 0; i--)
                {
                    if (obj.list_games[i].game.active.Equals("Y"))//jeśli grupa jest aktywna ...
                    {
                        comboBox.Items.Add(new ComboBoxItem { Content = obj.list_games[i].game.idg.ToString() });//... jest dodawana do listy elementów ComboBox
                    }
                }
            }
            catch (HttpRequestException ex)
            {
                Functions.Function.showMessage("Brak dostępu do Internetu. Sprawdź połączenie.\nNo internet access. Check connection.");
                //komunikat gdy pojawia się brak dostępu do Internetu
            }
        }

        private void getData(string data)//Sprawdzenie statusu logowania użytkownika
        {
            Classes.RootObject obj = JsonConvert.DeserializeObject<Classes.RootObject>(data);//zmienna gdzie konwertuje się zawartość odpowiedzi serwera z pliku .json
            string ResponseText = obj.user_login.result.ToString();//zmienna czy logowanie powiodło się
            if (ResponseText.Equals("True"))//gdy logowanie powiodło się
            {
                Frame.Navigate(typeof(MenuPage));//przenosi do kolejnej strony
            }
            else
            {
                Functions.Function.showMessage("Błędny login lub hasło.\nInvalid login or password.");//gdy logowanie nie powiodło się
            }
        }

        private void button_Click(object sender, RoutedEventArgs e)//Obsługuje logowanie
        {  
            try
            {
                Classes.Connection objConnection = new Classes.Connection();//Klasa dla dostępu do Internetu
                if (objConnection.CheckInternetAccess() == true)//Gdy jest dostęp do Internetu
                {
                    if (String.IsNullOrEmpty(logintextBox.Text) != true && String.IsNullOrEmpty(passwordBox.Password) != true)//Gdy pola dla wpisania loginu i hasła nie są puste
                    {
                        saveFile("true");//Zapisanie danych żeby nie wpisywać ponownie danych do logowania
                        login(logintextBox.Text, passwordBox.Password, ((ComboBoxItem)comboBox.SelectedItem).Content.ToString());
                        //Wartości inputów oraz comboBoxa są wysyłane do metody do logowania
                    }
                    else//Gdy wpisane dane nie są poprawne, wyświetla się komunikat
                    {
                        Functions.Function.showMessage("Uzupełnij dane do logowania.\nComplete the login data.");
                    }
                }
                else//Gdy nie ma dostępu do Internetu
                {
                    Functions.Function.showMessage("Brak dostępu do Internetu. Sprawdź połączenie.\nNo internet access. Check connection.");
                    startApp();
                }
            }
            catch (NullReferenceException ex)//Przy pojawieniu się wyjątku z błędem o braku referencji, wyświetla się komunikat
            {
                if (String.IsNullOrEmpty(logintextBox.Text) || String.IsNullOrEmpty(passwordBox.Password))//Gdy pola dla wpisania loginu i hasła są różne od pustego
                {
                    Functions.Function.showMessage("Uzupełnij dane do logowania.\nComplete the login data.");//Gdy pola dla wpisania loginu lub hasła są puste
                }
                else
                {
                    Functions.Function.showMessage("Wybierz grupę.\nSelect a group.");//Pozostało wybranie grupy
                }
            }
            catch (HttpRequestException ex)//Wyjątek przy braku dostępu do Internetu
            {
                Functions.Function.showMessage("Brak dostępu do Internetu. Sprawdź połączenie.\nNo internet access. Check connection.");
                startApp();
            }
            catch (Exception ex)//Przy pojawieniu się innego wyjątku z błędem, wyświetla się w konsoli treść błędu
            {
                Debug.WriteLine(ex);
            }
        }

        private async void resetTextBlock_Tapped(object sender, TappedRoutedEventArgs e)//Po naciśnięciu kontrolki resetTextBlock, przenosi do strony z resetem hasła do logowania
        {
            string url = @"https://www.edug.pl/remind.php";
            await Launcher.LaunchUriAsync(new Uri(url));//przenosi do strony z resetowaniem hasła
        }

        public void login(string login, string passs, string game)//Tworzy adres url do pobrania danych o logowaniu
        {
            string pswrd = PassedData.pswrd, system = PassedData.system, lang = PassedData.lang, sum;
            try
            {
                if (login != "" && passs != "")//gdy login i hasło nie są puste
                {
                    String hash = MD5CryptoServiceProvider.GetMd5String(passs);//hash jako skrót MD5 hasła użytkownika
                    sum = pswrd + system + lang + game + login + hash;//sum jako suma ciągu znaków hasła dostępu, systemu operacyjnego, języka, grupy, loginu oraz hashu
                    String crc = MD5CryptoServiceProvider.GetMd5String(sum);//hash jako skrót MD5 sumy ciągu znaków powyżej
                    //url jako gotowy odnośnik do pobrania danych o poprawności logowania
                    string url = @"https://www.edug.pl/_webservices/user_login.php?sys=" + system + "&lang=" + lang + "&game=" + game + "&login=" + login + "&hash=" + hash + "&crc=" + crc;
                    getList(two, url);//wywołanie metody do pobrania i sprawdzenia logowania
                }
                else//gdy login i/lub hasło są puste
                {
                    Functions.Function.showMessage("Uzupełnij dane do logowania.\nComplete the login data.");
                }
            }
            catch (HttpRequestException ex)//wyjątek przy braku dostępu do Internetu
            {
                Functions.Function.showMessage("Brak dostępu do Internetu. Sprawdź połączenie.\nNo internet access. Check connection.");
                startApp();
            }
            catch(Exception ex)//przy pojawieniu innego wyjątku
            {
                Debug.WriteLine(ex);
            }
        }

        public async void saveFile(string state)//Do zapisania danych, gdy agent nie wylogowuje się z niej oraz zamknie aplikację
        {
            try
            {
                StorageFolder folder = ApplicationData.Current.LocalFolder;//folder w którym jest zainstalowana aplikacja

                if (folder != null)//gdy w folderze jest plik
                {
                    if (state == "true")//przy zapisie pliku
                    {
                        //zastąpienie obecnej wersji pliku nową wersją
                        StorageFile sampleFile = await folder.CreateFileAsync("sample.txt", CreationCollisionOption.ReplaceExisting);
                        //zapisanie wartości loginu, hasła i kryptonim gry do klasy PassedData
                        PassedData.login = logintextBox.Text;
                        PassedData.loginPassword = passwordBox.Password;
                        PassedData.group = ((ComboBoxItem)comboBox.SelectedItem).Content.ToString();
                        //zapisanie do pliku statusu zapisu,wartość loginu, hasła i kryptonim gry
                        await FileIO.WriteTextAsync(sampleFile, "State:true");
                        await FileIO.AppendTextAsync(sampleFile, " login:" + logintextBox.Text);
                        await FileIO.AppendTextAsync(sampleFile, " password:" + passwordBox.Password);
                        await FileIO.AppendTextAsync(sampleFile, " game:" + ((ComboBoxItem)comboBox.SelectedItem).Content.ToString());
                    }
                    else if (state == "false")//usuwa plik z folderu przy wylogowaniu się i tworzy nowy
                    {
                        StorageFile sampleFile = await folder.CreateFileAsync("sample.txt", CreationCollisionOption.ReplaceExisting);
                        await FileIO.WriteTextAsync(sampleFile, "State:false");//brak potrzeby odczytania pliku
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
        }

        public async void loadFile()//Metoda do ładowania pliku, gdy agent nie wylogował się oraz zamknął i uruchomił ponownie aplikację
        {
            try
            {
                StorageFolder folder = ApplicationData.Current.LocalFolder;//Folder w którym jest zainstalowana aplikacja
                if (folder != null)
                {
                    var file = await folder.OpenStreamForReadAsync("sample.txt");//Otwarcie pliku

                    using (StreamReader streamReader = new StreamReader(file))//StreamReader służy do obłsugi odczytu plików
                    {
                        string text = streamReader.ReadToEnd();//Odczyt pliku do końca
                        string TextToGet = null;
                        string matchpattern = @"State:";//Wyszukiwany ciąg znaków do zmiany
                        string replacementpattern = @"";//Ciąg znaków do podmiany
                        string stateText = null, loginText = null, passText = null, gameText = null;//Pomocnicze ciągi znaków
                        
                        Regex state = new Regex(@"State:.+login");//Zmienna do wyszukania wyrażenia regularnego dla statusu odczytu
                        Match m = state.Match(text);//Zmienna do reprezentowania wyników wyszukiwania powyższej zmiennej state                   

                        for (int gIdx = 0; gIdx < m.Groups.Count; gIdx++)//Pętla do wyszukania ciągu znaków 
                        {
                            TextToGet = m.Groups[gIdx].Value.ToString();
                            if (String.IsNullOrEmpty(TextToGet)==false)//Gdy zmienna TextToGet nie jest pusta lub ma wartość null
                            {
                                int index = TextToGet.IndexOf(' ');//Do wyznaczenia indeksu dla spacji
                                TextToGet = TextToGet.Remove(index);//Usunięcie znaków od danego indeksu do końca ciągu znaków
                                stateText = Regex.Replace(TextToGet, matchpattern, replacementpattern);//Zastąpienie danego ciągu znaków innym ciągiem
                                if (stateText != "false")//Dla stateText równego true metoda dalej odczytuje zmienne potrzebne do logowania
                                {
                                    //Zmienne do wyszukania wyrażenia regularnego
                                    Regex login = new Regex(@"login:.+password");//dla loginu
                                    Regex password = new Regex(@"password:.+game");//dla hasła
                                    Regex game = new Regex(@"game:.+");//dla grupy

                                    Match l = login.Match(text);//Zmienna do reprezentowania wyników wyszukiwania powyższej zmiennej login
                                    Match p = password.Match(text);//Zmienna do reprezentowania wyników wyszukiwania powyższej zmiennej password
                                    Match g = game.Match(text);//Zmienna do reprezentowania wyników wyszukiwania powyższej zmiennej game

                                    matchpattern = @"login:";//Wyszukiwany ciąg znaków do zmiany
                                    for (int LIdx = 0; LIdx < l.Groups.Count; LIdx++)//Pętla do wyszukania ciągu znaków 
                                    {
                                        TextToGet = l.Groups[gIdx].Value.ToString();
                                        index = TextToGet.IndexOf(' ');//Do wyznaczenia indeksu dla spacji
                                        TextToGet = TextToGet.Remove(index);//Usunięcie znaków od danego indeksu do końca ciągu znaków
                                        loginText = Regex.Replace(TextToGet, matchpattern, replacementpattern);//Zastąpienie danego ciągu znaków innym ciągiem
                                        PassedData.login = loginText;//Zapisanie wartości (adres email agenta)
                                    }
                                    matchpattern = @"password:";//Wyszukiwany ciąg znaków do zmiany
                                    for (int pIdx = 0; pIdx < p.Groups.Count; pIdx++)//Pętla do wyszukania ciągu znaków 
                                    {
                                        TextToGet = p.Groups[pIdx].Value.ToString();
                                        index = TextToGet.IndexOf(' ');//do wyznaczenia indeksu dla spacji
                                        TextToGet = TextToGet.Remove(index);//usunięcie znaków od danego indeksu do końca ciągu znaków
                                        passText = Regex.Replace(TextToGet, matchpattern, replacementpattern);//Zastąpienie danego ciągu znaków innym ciągiem
                                        PassedData.loginPassword = passText;//Zapisanie wartości (hasło agenta)
                                    }
                                    matchpattern = @"game:";//Wyszukiwany ciąg znaków do zmiany
                                    for (int Idx = 0; Idx < g.Groups.Count; Idx++)//Pętla do wyszukania ciągu znaków 
                                    {
                                        TextToGet = g.Groups[Idx].Value.ToString();
                                        gameText = Regex.Replace(TextToGet, matchpattern, replacementpattern);//Zastąpienie danego ciągu znaków innym ciągiem
                                        PassedData.group = gameText;//Zapisanie wartości (identyfikator gry agenta)
                                    }
                                    //Gdy jedna ze zmiennych jest pusta lub wynosi null, dalej kontynuuje jak przy nowym uruchomieniu aplikacji
                                    if (String.IsNullOrEmpty(loginText) || String.IsNullOrEmpty(passText) || String.IsNullOrEmpty(gameText))
                                    {
                                        string link = @"http://www.edug.pl/_webservices/list_games.php";
                                        getList(one, link);
                                    }
                                    else
                                    {
                                        //lub zapisuje zmienne i przechodzi do logowania
                                        PassedData.login = loginText;
                                        PassedData.loginPassword = passText;
                                        PassedData.group = gameText;
                                        this.login(loginText, passText, gameText);
                                    }
                                }
                                else
                                {
                                    //Dalej kontynuuje jak przy nowym uruchomieniu aplikacji
                                    string link = @"http://www.edug.pl/_webservices/list_games.php";
                                    getList(one, link);
                                }
                            }
                            else//W innym przypadku kontynuuje pracę dalej jak przy nowym uruchomieniu aplikacji
                            {
                                string link = @"http://www.edug.pl/_webservices/list_games.php";
                                getList(one, link);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)//Wyświetlenie wyjątku oraz kontynuuje pracę dalej jak przy nowym uruchomieniu aplikacji
            {
                Debug.WriteLine(ex);
                string link = @"http://www.edug.pl/_webservices/list_games.php";
                getList(one, link);
            }
        }
    }
}

