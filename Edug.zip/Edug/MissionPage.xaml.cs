﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Text.RegularExpressions;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using static Edug.Classes;

//LISTA AKTYWNYCH MISJI
namespace Edug
{
    public sealed partial class MissionPage : Page
    {
        public MissionPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)//Wywowyłana gdy strona stanie się aktywna
        {
            PassedData.startString = null;//Wyczyszczenie pola z godziną rozpoczęcia misji
            PassedData.finishString = null;//Wyczyszczenie pola z godziną zakończenia misji
            PassedData.slownik.Clear();//Wyczyszczenie zawartości słownika
            list.Items.Clear();//Wyczyszczenie listy z misjami specjalnymi
            lablist.Items.Clear();//Wyczyszczenie listy z misjami laboratoryjnymi
            fastlist.Items.Clear();//Wyczyszczenie listy z misjami błyskawicznymi

            setLanguage();//Ustawienie wyświetlanego tekstu według języka agenta
            Functions.Function.getInfo();//Funkcja do aktualizacji informacji nt. zdobytych punktów przez agenta
            setAppBar();//Ustawienie wartości zdobytych punktów przez agenta
            getMissions();//Metoda do pobrania misji
        }

        public string idmSpecString, idmLabString, idmFastString, idmHazdString, idmLastString;
        //stringi do linijek dla poszczególnych misji wraz z numerem misji: idmSpecString - dla specjalnej, idmLabString - dla laboratoryjnej
        //idmFastString - dla błyskawicznej, idmHazdString - dla , idmLastString
        public string start, stop, startText, stopText;//pomocnicze stringi do czasu

        public int hazardStart, hazardStop, finalStart, finalStop;//Pomocnicze stringi do czasu dla misji hazardowej i ostatecznej

        public string type = PassedData.missionType;//Typ misji - specjalna, laboratoryjna, błyskawiczna, hazardowa lub ostateczna

        public class MissionFast//Klasa dla misji ze zmiennymi, które są wykorzystywane przez metody w dalszej części dokumentu
        {
            public bool result { get; set; }//Rezultat czy dane wysłane do serwera były poprawne, jeśli tak to przyjmuje wartość "true", 
            public string comment { get; set; }//w przeciwnnym wypadku result ma wartość "false" i komunikat błędu w zmiennej "comment"
            public string codename { get; set; }//Kryptonim misji
            public object picture { get; set; }//Obrazek do pytania
            public string intro_time { get; set; }//Data tekstu wstępnego
            public string intro_text { get; set; }//Komentarz na początku misji
            public string mission_start { get; set; }//Godzina o której misja się rozpoczyna
            public string mission_text { get; set; }//Komentarz do misji
            public string finish_time { get; set; }//Godzina o której misja się zakończy
            public string finish_text { get; set; }//Komentarz na końcu misji
            public string question { get; set; }//Treść pytania
            public string mission { get; set; }//Identyfikator misji np. 103, 110
            public string answers_1 { get; set; }//Treść odpowiedzi nr 1
            public string answers_2 { get; set; }//Treść odpowiedzi nr 2
            public string answers_3 { get; set; }//Treść odpowiedzi nr 3
            public string answers_4 { get; set; }//Treść odpowiedzi nr 4
        }

        public class RootObject//Klasa która dziedziczy po klasie MissionFast
        {
            public MissionFast mission_fast { get; set; }
        }

        public void setLanguage()//Ustawia wyświetlany tekst według języka agenta
        {
            string specHeader, labHeader, fastHeader, hazdHeader, finalHeader;//nagłówki stron z misjami
            switch (PassedData.lang)
            {
                case "pl"://dla polskiego agenta
                    specHeader = "Specjalne";//treść nagłówka strony z listą numerów misji specjalnych
                    labHeader = "Laboratoryjne";//treść nagłówka strony z listą numerów misji laboratoryjnych
                    fastHeader = "Błyskawiczne";//treść nagłówka strony z listą numerów misji błyskawicznych
                    hazdHeader = "Hazardowa";//treść nagłówka strony z misją hazardową
                    finalHeader = "Ostateczna";//treść nagłówka strony z misją ostateczną
                    pivot_specjal.Header = specHeader;//nagłówek dla strony z listą numerów misji specjalnych
                    pivot_lab.Header = labHeader;//nagłówek dla strony z listą numerów misji laboratoryjnych
                    pivot_fast.Header = fastHeader; ;//nagłówek dla strony z listą numerów misji błyskawicznych
                    pivot_hazard.Header = hazdHeader;//nagłówek dla strony z misją hazardową
                    pivot_final.Header = finalHeader;//nagłówek dla strony z misją ostateczną
                    idmSpecString = "Misja specjalna ";//treść linii dla misji specjalnej razem z numerem misji
                    idmLabString = "Misja laboratoryjna ";//treść linii dla misji laboratoryjnej razem z numerem misji
                    idmFastString = "Misja błyskawiczna ";//treść linii dla misji błyskawicznej razem z numerem misji
                    idmHazdString = "KUPUJĘ PYTANIE";//tekst na przycisku do zakupu pytania dla misji hazardowej
                    idmLastString = "KUPUJĘ PYTANIE";//tekst na przycisku do zakupu pytania dla misji hazardowej
                    startText = "Misja nie rozpoczęła się jeszcze.";//treść komunikatu gdy misja jeszcze nie rozpoczęła się
                    stopText = "Misja zakończona.";//treść komunikatu gdy misja zakończyła się
                    BackButton.Label = "Powrót";//treśc przycisku do przejścia do poprzedniej strony
                    LogoutButton.Label = "Wyloguj";//treśc przycisku do przejścia do poprzedniej strony
                    //poniżej są teksty które są wyświetlane w tabelce dla misji hazardowej
                    hazdRequireTextBlock.Text = "Wymóg";
                    hazdRequireText.Text = "opcjonalna";
                    hazdStartTimeTextBlock.Text = "Start";
                    hazdFinishTimeTextBlock.Text = "Koniec";
                    hazdCountTextBlock.Text = "Pytań";
                    hazdOrderTextBlock.Text = "Kolejność";
                    hazdOrderText.Text = "losowa";
                    hazdPriceTextBlock.Text = "Koszt pytania";
                    hazdPriceText.Text = "4฿";
                    //poniżej są teksty które są wyświetlane w tabelce dla misji ostatecznej
                    lastRequireTextBlock.Text = "Wymóg";
                    lastRequireText.Text = "obowiązkowa";
                    lastStartTimeTextBlock.Text = "Start";
                    lastFinishTimeTextBlock.Text = "Koniec";
                    lastCountTextBlock.Text = "Pytań";
                    lastOrderTextBlock.Text = "Kolejność";
                    lastOrderText.Text = "losowa";
                    lastPriceTextBlock.Text = "Koszt pytania";
                    lastPriceText.Text = "1$";
                    break;
                case "en"://dla zagranicznego agenta, który ma test wyświetlany w języku angielskim
                    specHeader = "Special";
                    labHeader = "Lab";
                    fastHeader = "Fast";
                    hazdHeader = "Gambling";
                    finalHeader = "Final";
                    pivot_specjal.Header = specHeader;
                    pivot_lab.Header = labHeader;
                    pivot_fast.Header = fastHeader;
                    pivot_hazard.Header = hazdHeader;
                    pivot_final.Header = finalHeader;
                    idmSpecString = "Special mission ";
                    idmLabString = "Lab mission ";
                    idmFastString = "Fast mission ";
                    idmHazdString = "I AM BYUING A QUESTION";
                    idmLastString = "I AM BYUING A QUESTION";
                    startText = "The mission has not started yet.";
                    stopText = "Mission accomplished.";
                    BackButton.Label = "Back";
                    LogoutButton.Label = "Logout";
                    //poniżej są teksty które są wyświetlane w tabelce dla misji hazardowej
                    hazdRequireTextBlock.Text = "Requirement";
                    hazdRequireText.Text = "optional";
                    hazdStartTimeTextBlock.Text = "Start";
                    hazdFinishTimeTextBlock.Text = "Finish";
                    hazdCountTextBlock.Text = "Questions";
                    hazdOrderTextBlock.Text = "Order";
                    hazdOrderText.Text = "random";
                    hazdPriceTextBlock.Text = "The cost of the question";
                    hazdPriceText.Text = "4฿";
                    //poniżej są teksty które są wyświetlane w tabelce dla misji ostatecznej
                    lastRequireTextBlock.Text = "Requirement";
                    lastRequireText.Text = "mandatory";
                    lastStartTimeTextBlock.Text = "Start";
                    lastFinishTimeTextBlock.Text = "Finish";
                    lastCountTextBlock.Text = "Questions";
                    lastOrderTextBlock.Text = "Order";
                    lastOrderText.Text = "random";
                    lastPriceTextBlock.Text = "The cost of the question";
                    lastPriceText.Text = "1$";
                    break;
            }
        }

        public void setAppBar()//Ustawia treść i wartość przycisków na belce w dolnej części ekranu
        {
            AvatarAddAppBarButton.Label = PassedData.count_avatar + PassedData.countAvatarString;//Tekst i wartość dla avatarów
            BitcoinAddAppBarButton.Label = PassedData.count_bitcoin + PassedData.countBitcoinString;//Tekst i wartość dla bitcoinów
            ExacoinAddAppBarButton.Label = PassedData.count_exacoin + PassedData.countExacoinString;//Tekst i wartość dla exacoinów
            PointsAddAppBarButton.Label = PassedData.count_point + PassedData.countPointString;//Tekst i wartość dla punktów
        }

        public async void getMissions()//Obsługuje uzyskanie listy wszystkich (nie tylko aktywnych) misji
        {
            string login = PassedData.agent_email, pswrd = PassedData.pswrd, passs = PassedData.loginPassword, system = PassedData.system, lang = PassedData.lang, game = PassedData.group;
            //w login zapisany jest adres email agenta, pswrd - każdy z ważnych webserwisow wylicza crc zabezpieczone hasłem, crc wyliczone jako md5 od konkatenacji wszystkich argumentów poprzedzonych hasłem, tutaj hasłem jest wartość pswrd
            //passs - hasło agenta, system - system operacyjny, lang - język wyświetlanego tekstu dla agenta, game - numer grupy agenta 
            string ResponseText1;//lokalna zmienna pomocnicza, w niej zapisywana jest odpowiedź od serwera
            try
            {
                using (HttpClient client = new HttpClient())//Utworzenie klienta http w celu obsługi adresu url
                {
                    //Inicjowanie nowej instacji klasy Uri z podanym adresem do listy misji
                    string link = @"http://www.edug.pl/_webservices/list_missions.php?idg=" + PassedData.group; //idg - identyfikator gry agenta
                    var uri = new Uri(link);//Inicjowanie nowej instacji klasy Uri z podanym adresem strony
                    client.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;//Sprawdzenie czy zaszła zmiana od ostatniego żądania do serwera od momentu wysłania zapytania
                    //Wysyła żądanie GET dla danego odnosnika URL
                    var Response = await client.GetAsync(uri);
                    //Rezultat i kod
                    var statusCode = Response.StatusCode;
                    //Jeśli odpowiedź jest inna od Http 200
                    //wtedy metoda EnsureSuccessStatusCode wyrzuci wyjątek
                    Response.EnsureSuccessStatusCode();
                    //Jeśli odpowiedź jest inna od Http 200
                    //wtedy metoda EnsureSuccessStatusCode wyrzuci wyjątek
                    ResponseText1 = await Response.Content.ReadAsStringAsync();//Pobranie asynchronicznie odpowiedzi od serwera
                    client.CancelPendingRequests();//Anulowanie wszelkich żądań do serwera
                    client.Dispose();//Zamknięcie klienta
                    getMission(ResponseText1);//Obsługa pliku json by uzyskać listę misji
                }   
            }
            catch (Exception ex)//Przy pojawieniu się wyjątku z błędem wyświetla się w konsoli
            {
                Debug.WriteLine(ex);
            }
        }

        public void getMission(string edata)//Obsługuje segregowanie misji według kategorii, zmienna edata to odpowiedź otrzymana od webserwera
        {
            try
            {
                Classes.RootObject obj = JsonConvert.DeserializeObject<Classes.RootObject>(edata);//Przetworzenie pliku json do typu .NET
                string count = "86";//Liczba pytań dla misji hazardowej i ostatecznej, które wyświetla się w tabelce
                int licznik = obj.list_missions.Count;//Liczba wszystkich misji
                for (int i = 0; i < licznik; i++)
                {
                    var item = new Classes.Mission();//Utworzenie obiektu jako nowej instacji klasy Mission 
                    string idm = obj.list_missions[i].mission.idm;//Numer misji
                    string type = obj.list_missions[i].mission.type;//Kategoria misji
                    start = obj.list_missions[i].mission.start;//Godzina rozpoczęcia misji
                    stop = obj.list_missions[i].mission.stop;//Godzina końca misji
                    DateTime enteredTime = DateTime.Parse(start);//Konwersja ciągu znaków reprezentujący datę i godzinę czasu rozpoczęcia misji na odpowiednik DateTime
                    DateTime finishedTime = DateTime.Parse(stop);//Konwersja ciągu znaków reprezentujący datę i godzinę czasu zakończenia misji na odpowiednik DateTime
                    DateTime nowTime = DateTime.Now;//Zmienna lokalna której wartość jest aktualna data i godzina
                    int enterResult = DateTime.Compare(nowTime, enteredTime);//Porównanie godziny aktualnej z godziną startu misji w celu sprawdzenia czy misja rozpoczęła się
                    //1 - aktualna godzina jest później niż godzina rozpoczęcia misji, -1 - aktualna godzina jest wcześniej niż godzina rozpoczęcia misji, 0 - taka sama godzina 
                    int finishResult = DateTime.Compare(nowTime, finishedTime);//Porównanie godziny aktualnej z godziną końca misji w celu sprawdzenia czy misja zakończyła się
                    //1 - aktualna godzina jest później niż godzina rozpoczęcia misji, -1 - aktualna godzina jest wcześniej niż godzina rozpoczęcia misji, 0 - taka sama godzina 
                    PassedData.startString = start;//Zapisanie godziny rozpoczęcia misji
                    PassedData.finishString = stop;//Zapisanie godziny końca misji
                    lastCountText.Text = count;
                    hazdCountText.Text = count;
                    switch (type)//segregacja misji według kategorii
                    {
                        case "hazd"://dla misji hazardowej
                            hazardStart = enterResult;
                            hazardStop = finishResult;
                            hazdStartTimeText.Text = start;//wyświetlenie godziny startu misji hazardowej
                            hazdFinishTimeText.Text = stop;///wyświetlenie godziny końca misji hazardowej
                            break;
                        case "last"://dla misji ostatecznej
                            finalStart = enterResult;
                            finalStop = finishResult;
                            lastStartTimeText.Text = start;//wyświetlenie godziny startu misji ostatecznej
                            lastFinishTimeText.Text = stop;///wyświetlenie godziny końca misji ostatecznej
                            break;
                        default:
                            break;
                    }
                    if (enterResult > 0)//jeśli godzina odczytu jest później niż godzina rozpoczęcia misji
                    {
                        if (finishResult < 0)//jeśli godzina odczytu jest wcześniej niż godzina zakończenia misji
                        {
                            switch (type)//w zależności od kategorii
                            {
                                case "spec"://zapisanie do listy z misjami specjalnymi
                                    if (PassedData.slownik.ContainsKey(idm))//sprawdzenie czy w słowniku czy istnieje klucz
                                    {
                                        if (type != PassedData.slownik[idm])//sprawdzenie czy wartość jest inna niż wartość o podanym kluczu, jeśli jest inna to wpisuje wartość
                                        {
                                            item.idm = idmSpecString + idm;//łączenie słów "misja specjalna" z numerem misji, np. 308 i ustawienie tego dla pola item
                                            PassedData.slownik.Add(idm, type);//dodanie do słownika numer misji jako klucz, a kategoria misji jako klucz 
                                            list.Items.Add(item);//dodanie połączonych słów z numerem misji do listy, gdzie zostaną wyświetlone
                                        }
                                    }
                                    else//gdy w słowniku nie ma danego klucza
                                    {
                                        item.idm = idmSpecString + idm;
                                        PassedData.slownik.Add(idm, type);
                                        list.Items.Add(item);
                                    }
                                    break;
                                case "labo"://zapisanie do listy z misjami laboratoryjnymi
                                    if (PassedData.slownik.ContainsKey(idm))//sprawdzenie czy w słowniku czy istnieje klucz
                                    {
                                        if (type != PassedData.slownik[idm])//sprawdzenie czy wartość jest inna niż wartość o podanym kluczu, jeśli jest inna to wpisuje wartość
                                        {
                                            item.idm = idmLabString + idm;//łączenie słów "misja specjalna" z numerem misji, np. 208 i ustawienie tego dla pola item
                                            PassedData.slownik.Add(idm, type);//dodanie do słownika numer misji jako klucz, a kategoria misji jako klucz 
                                            lablist.Items.Add(item);//dodanie połączonych słów z numerem misji do listy, gdzie zostaną wyświetlone
                                        }
                                    }
                                    else//gdy w słowniku nie ma danego klucza
                                    {
                                        item.idm = idmLabString + idm;
                                        PassedData.slownik.Add(idm, type);
                                        lablist.Items.Add(item);
                                    }
                                    break;
                                case "fast"://zapisanie do listy z misjami błyskawicznymi
                                    if (PassedData.slownik.ContainsKey(idm))//sprawdzenie czy w słowniku czy istnieje klucz
                                    {
                                        if (type != PassedData.slownik[idm])//sprawdzenie czy wartość jest inna niż wartość o podanym kluczu, jeśli jest inna to wpisuje wartość
                                        {
                                            item.idm = idmFastString + idm;//łączenie słów "misja specjalna" z numerem misji, np. 108 i ustawienie tego dla pola item
                                            PassedData.slownik.Add(idm, type);//dodanie do słownika numer misji jako klucz, a kategoria misji jako klucz 
                                            fastlist.Items.Add(item);//dodanie połączonych słów z numerem misji do listy, gdzie zostaną wyświetlone
                                        }
                                    }
                                    else//gdy w słowniku nie ma danego klucza
                                    {
                                        item.idm = idmFastString + idm;
                                        PassedData.slownik.Add(idm, type);
                                        fastlist.Items.Add(item);
                                    }
                                    break;
                                case "hazd"://w przypadku misji hazardowej
                                    if (String.IsNullOrEmpty(idm))//gdy nie ma podanego numeru misji, jest on zastąpiony słowem
                                    {
                                        idm = "hazd";
                                    }
                                    if (PassedData.slownik.ContainsKey(idm))//sprawdzenie czy w słowniku czy istnieje klucz
                                    {
                                        if (type != PassedData.slownik[idm])//sprawdzenie czy wartość jest inna niż wartość o podanym kluczu, jeśli jest inna to wpisuje wartość
                                        {
                                            item.idm = idm;//ustawienie numeru misji dla pola item
                                            PassedData.slownik.Add(idm, type);//dodanie do słownika numer misji jako klucz, a kategoria misji jako klucz 
                                            hazdButtonTextBlock.Text = idmHazdString;//ustawienie tekstu na przycisku do zakupu pytania 
                                        }
                                    }
                                    else//gdy w słowniku nie ma danego klucza
                                    {
                                        item.idm = idm;//ustawienie numeru misji dla pola item
                                        PassedData.slownik.Add(idm, type);//dodanie do słownika numer misji jako klucz, a kategoria misji jako klucz 
                                        hazdButtonTextBlock.Text = idmHazdString;//ustawienie tekstu na przycisku do zakupu pytania
                                    }
                                    break;
                                case "last"://w przypadku misji ostatecznej
                                    if (String.IsNullOrEmpty(idm))//gdy nie ma podanego numeru misji, jest on zastąpiony słowem
                                    {
                                        idm = "last";
                                    }
                                    if (PassedData.slownik.ContainsKey(idm))//sprawdzenie czy w słowniku czy istnieje klucz
                                    {
                                        if (type != PassedData.slownik[idm])//sprawdzenie czy wartość jest inna niż wartość o podanym kluczu, jeśli jest inna to wpisuje wartość
                                        {
                                            item.idm = idm;//ustawienie numeru misji dla pola item
                                            PassedData.slownik.Add(idm, type);//dodanie do słownika numer misji jako klucz, a kategoria misji jako klucz 
                                            finalButtonTextBlock.Text = idmLastString;//ustawienie tekstu na przycisku do zakupu pytania 
                                        }
                                    }
                                    else//Gdy w słowniku nie ma danego klucza
                                    {
                                        item.idm = idm;//Ustawienie numeru misji dla pola item
                                        PassedData.slownik.Add(idm, type);//Dodanie do słownika numer misji jako klucz, a kategoria misji jako klucz 
                                        finalButtonTextBlock.Text = idmLastString;//Ustawienie tekstu na przycisku do zakupu pytania 
                                    }  
                                    break;
                                default:
                                    Debug.WriteLine(type, idm, start, stop);//W przypadku misji która nie należy do żadnej kategorii, wyświetlenie informacji o niej w konsoli
                                    break;
                            }
                        }
                        else
                        {
                            switch (type)//w zależności od kategorii
                            {
                                case "hazd":
                                    hazdButton.Visibility = Visibility.Collapsed;//Niewidoczny przycisk do zakupu pytania jeśli misja zakończyła się
                                    break;
                                case "last":
                                    finalButton.Visibility = Visibility.Collapsed;//Niewidoczny przycisk do zakupu pytania jeśli misja zakończyła się
                                    break;
                            }
                        }
                    }
                    else
                    {
                        switch (type)//w zależności od kategorii
                        {
                            case "hazd":
                                hazdButton.Visibility = Visibility.Collapsed;//Niewidoczny przycisk do zakupu pytania jeśli misja nie rozpoczęła się
                                break;
                            case "last":
                                finalButton.Visibility = Visibility.Collapsed;//Niewidoczny przycisk do zakupu pytania jeśli misja nie rozpoczęła się
                                break;
                        }    
                    }
                }
            }
            catch (Exception ex)//W przypadku przechwycenia wyjątku z błędem, wyświetlenie w konsoli treści błędu
            {
                Debug.WriteLine(ex);
            }
        }

        private void list_SelectionChanged(object sender, SelectionChangedEventArgs e)//Obsługuje wybór elementu z listy misji i wyznaczenia numeru oraz typu misji
        {
            Classes.Mission myobject = (sender as ListView).SelectedItem as Classes.Mission;//Utworzenie obiektu klasy Mission, gdzie ustawiane są wartości z wybranego elementu z ListView 
            if (myobject != null)//Gdy obiekt przyjmuje wartość różną od pustej
            {
                string value, key = myobject.idm;//W zmiennej "key" zapisany jest wartość wybranej linii z numerem misji

                Regex re = new Regex(@"\d\d\d");//Utworzenie wyrażenia regularnego określającego trzycyfrową liczbę jako numer misji
                MatchCollection mc = re.Matches(key);//Utworzenie zestawu elementów, które są zgodne z wyrażeniem regularnym "re"
                foreach (Match m in mc)//Sprawdzenie każdego elementu z zestawu w pętli
                {
                    for (int gIdx = 0; gIdx < m.Groups.Count; gIdx++)
                    {
                        key = m.Groups[gIdx].Value;//Ustawienie wartości zmiennej "key", jest to numer misji
                    }
                }

                if (PassedData.slownik.ContainsKey(key))//Gdy w słowniku istnieje podana wartość klucza
                {
                    PassedData.missionNumber = key;//Zapisanie numeru misji
                    value = PassedData.slownik[key];//Uzyskanie kateogrii misji jako wartość z podanego klucza "key"
                    PassedData.missionType = value;//Zapisanie kategorii misji
                    Frame.Navigate(typeof(QuestionPage));//Przejście do kolejnej strony, gdzie będzie wyświetlone pytanie wraz z odpowiedziami dla podanego numeru i kategorii misji
                }
            }
        }

        private async void finalButton_Click(object sender, RoutedEventArgs e)//Obsługuje naciśnięcie przycisku do zakupu pytania dla misji ostatecznej
        {
            string login = PassedData.agent_email, pswrd = PassedData.pswrd, passs = PassedData.loginPassword, system = PassedData.system, lang = PassedData.lang, game = PassedData.group, sum1;
            //W zmiennej login jest zapisany adres email agenta, w zmiennej pswrd - hasło dostępu do webserwera, w zmiennej pass - hasło agenta,
            //w zmiennej system - system operacyjny, w zmiennej lang - język agenta, w zmiennej game - identyfikator gry agenta
            if (finalStart > 0)//Jeśli godzina odczytu jest później niż godzina rozpoczęcia misji
            {
                if (finalStop < 0)//Jeśli godzina odczytu jest później niż godzina rozpoczęcia misji
                {
                    string value, key = "last";//zmienne lokalne
                    if (PassedData.slownik.ContainsKey(key))//Gdy w słowniku istnieje podana wartość klucza key
                    {
                        PassedData.missionNumber = null;//Misja ostateczna nie ma numeru misji
                        value = PassedData.slownik[key];//Uzyskanie kategorii misji jako wartość z podanego klucza "key"
                        PassedData.missionType = value;//Zapisanie kategorii misji
                        String hash = MD5CryptoServiceProvider.GetMd5String(passs);//Skrót MD5 hasła użytkownika
                        sum1 = pswrd + system + lang + game + login + hash;//W zmiennej sum1 jest zapisany suma połączonych ciągu znaków zmiennych: pswrd, system, lang, game, login 
                        String crc1 = MD5CryptoServiceProvider.GetMd5String(sum1);//Skrót MD5 zmiennej sum1
                        string url = @"http://www.edug.pl/_webservices/mission_last.php?sys=" + system + "&lang=" + lang + "&game=" + game + "&login=" + login + "&hash=" + hash + "&crc=" + crc1;
                        //Zmienna url to adres do strony gdzie pobrane zostaną informacje nt. misji ostatecznej
                        try
                        {
                            using (HttpClient client = new HttpClient())//Utworzenie klienta http w celu obsługi adresu url
                            {
                                Uri uri = new Uri(url);//Inicjowanie nowej instacji klasy Uri z podanym adresem do listy misji
                                client.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;//Sprawdzenie czy zaszła zmiana od ostatniego żądania do serwera od momentu wysłania zapytania
                                var Response = await client.GetAsync(uri);//Wysyła żądanie GET dla danego odnośnika URL
                                var statusCode = Response.StatusCode;//Jeśli odpowiedź jest inna od Http 200
                                Response.EnsureSuccessStatusCode();//Wtedy metoda EnsureSuccessStatusCode wyrzuci wyjątek
                                var ResponseText = await Response.Content.ReadAsStringAsync();//Pobranie asynchronicznie odpowiedzi (plik .json) od serwera 
                                client.CancelPendingRequests();//Anulowanie wszelkich żądan do serwera
                                client.Dispose();//Zamknięcie klienta
                                String matchpattern = @"\<\w\w.\\\/\>";//Wzór tekstu do znalezienia dla wyrażenia regularnego
                                String replacementpattern = @"\n";//Wzór tekstu do podmiany dla wyrażenia regularnego
                                ResponseText = Regex.Replace(ResponseText, matchpattern, replacementpattern);
                                //W treści odpowiedzi serwera (ResponseText) metoda Regex stara znaleźć tekst o podanym wzorze (matchpattern) i go podmienić na inny (replacementpattern)
                                RootObject obj = JsonConvert.DeserializeObject<RootObject>(ResponseText);//Konwersja pliku .json na typy zgodne dla .NETu
                                string result = obj.mission_fast.result.ToString();//Wyznaczenie rezultatu z odpowiedzi od webserwera
                                string comment = obj.mission_fast.comment;//Wyznaczenie komentarza w przypadku błędnych danych
                                if (result == "True")//Gdy dane są zgodne, to jest zapisany adres url i przeniesienie do strony, gdzie będzie wyświetlone pytanie wraz z odpowiedziami dla podanej kategorii misji
                                {
                                    PassedData.urlForQuestion = url;
                                    Frame.Navigate(typeof(QuestionForLastPage));
                                }
                                else//W przypadku błędnych danych zostanie wyświetlony agentowi komunikat z treścią błędu
                                {
                                    Functions.Function.showMessage(comment);
                                }
                                ResponseText = null;//Wyczyszczenie pola z odpowiedzią od serwera
                                PassedData.urlForQuestion = null;//Wyczyszczenie pola z adresem url
                            }
                        }
                        catch (Exception ex)//W przypadku przechwycenia wyjątku z błędem, wyświetlenie w konsoli treści błędu
                        {
                            Debug.WriteLine(ex);
                        }
                    }
                }
                else//W przypadku zakończenia misji zostanie wyświetlony agentowi komunikat
                {
                    Functions.Function.showMessage(stopText);
                }
            }
            else//W przypadku gdy misja nie rozpoczęła się, zostanie wyświetlony agentowi komunikat
            {
                Functions.Function.showMessage(startText);
            }
        }

        private async void hazdButton_Click(object sender, RoutedEventArgs e)//Obsługuje naciśnięcie przycisku do zakupu pytania dla misji hazardowej
        {
            string login = PassedData.agent_email, pswrd = PassedData.pswrd, passs = PassedData.loginPassword, system = PassedData.system, lang = PassedData.lang, game = PassedData.group, sum1;
            //W zmiennej login jest zapisany adres email agenta, w zmiennej pswrd - hasło dostępu do webserwera, w zmiennej pass - hasło agenta,
            //w zmiennej system - system operacyjny, w zmiennej lang - język agenta, w zmiennej game - identyfikator gry agenta
            if (hazardStart > 0)//Jeśli godzina odczytu jest później niż godzina rozpoczęcia misji
            {
                if (hazardStop < 0)//Jeśli godzina odczytu jest później niż godzina rozpoczęcia misji
                {
                    string value, key = "hazd";//Zmienne lokalne
                    if (PassedData.slownik.ContainsKey(key))//Gdy w słowniku istnieje podana wartość klucza key
                    {
                        PassedData.missionNumber = null;//Misja hazardowa nie ma numeru misji
                        value = PassedData.slownik[key];//Uzyskanie kategorii misji jako wartość z podanego klucza "key"
                        PassedData.missionType = value;//Zapisanie kategorii misji
                        String hash = MD5CryptoServiceProvider.GetMd5String(passs);//Skrót MD5 hasła użytkownika
                        sum1 = pswrd + system + lang + game + login + hash;//W zmiennej sum1 jest zapisany suma połączonych ciągu znaków zmiennych: pswrd, system, lang, game, login 
                        String crc1 = MD5CryptoServiceProvider.GetMd5String(sum1);//Skrót MD5 zmiennej sum1
                        string url = @"http://www.edug.pl/_webservices/mission_hazd.php?sys=" + system + "&lang=" + lang + "&game=" + game + "&login=" + login + "&hash=" + hash + "&crc=" + crc1;
                        //Zmienna url to adres do strony gdzie pobrane zostaną informacje nt. misji ostatecznej
                        try
                        {
                            using (HttpClient client = new HttpClient())//Utworzenie klienta http w celu obsługi adresu url
                            {
                                Uri uri = new Uri(url);//Inicjowanie nowej instacji klasy Uri z podanym adresem do listy misji
                                client.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;//Sprawdzenie czy zaszła zmiana od ostatniego żądania do serwera od momentu wysłania zapytania
                                var Response = await client.GetAsync(uri);//Wysyła żądanie GET dla danego odnośnika URL
                                var statusCode = Response.StatusCode;//Jeśli odpowiedź jest inna od Http 200
                                Response.EnsureSuccessStatusCode();//Wtedy metoda EnsureSuccessStatusCode wyrzuci wyjątek
                                var ResponseText = await Response.Content.ReadAsStringAsync();//Pobranie asynchronicznie odpowiedzi (plik .json) od serwera
                                client.CancelPendingRequests();//Anulowanie wszelkich żądan do serwera
                                client.Dispose();//Zamknięcie klienta
                                String matchpattern = @"\<\w\w.\\\/\>";//Wzór do znalezienia dla wyrażenia regularnego
                                String replacementpattern = @"\n";//Wzór do podmiany dla wyrażenia regularnego
                                ResponseText = Regex.Replace(ResponseText, matchpattern, replacementpattern);
                                //W treści odpowiedzi serwera (ResponseText) metoda Regex stara znaleźć tekst o podanym wzorze (matchpattern) i go podmienić na inny (replacementpattern)
                                RootObject obj = JsonConvert.DeserializeObject<RootObject>(ResponseText);//Konwersja pliku .json na typy zgodne dla .NETu
                                string result = obj.mission_fast.result.ToString();//Wyznaczenie rezultatu z odpowiedzi od webserwera
                                string comment = obj.mission_fast.comment;//Wyznaczenie komentarza w przypadku błędnych danych
                                if (result == "True")//Gdy dane są zgodne, to jest zapisany adres url i przeniesienie do strony, gdzie będzie wyświetlone pytanie wraz z odpowiedziami dla podanej kategorii misji
                                {
                                    PassedData.urlForQuestion = url;
                                    Frame.Navigate(typeof(QuestionForLastPage));
                                }
                                else//W przypadku błędnych danych zostanie wyświetlony agentowi komunikat z treścią błędu
                                {
                                    Functions.Function.showMessage(comment);
                                }
                                ResponseText = null;//wyczyszczenie pola z odpowiedzią od serwera
                                PassedData.urlForQuestion = null;//wyczyszczenie pola z adresem url
                            }
                        }
                        catch (Exception ex)//W przypadku przechwycenia wyjątku z błędem, wyświetlenie w konsoli treści błędu
                        {
                            Debug.WriteLine(ex);
                        }
                        //---------------------------------------------------------------------------
                    }
                }
                else//W przypadku zakończenia misji zostanie wyświetlony agentowi komunikat
                {
                    Functions.Function.showMessage(stopText);
                }
            }
            else//W przypadku gdy misja nie rozpoczęła się, zostanie wyświetlony agentowi komunikat
            {
                Functions.Function.showMessage(startText);
            }
        }

        private void backButton_Click(object sender, RoutedEventArgs e)//Naciśnięcie przycisku powoduje powrót do poprzedniej strony
        {
            /*
            PassedData.startString = null;//Wyczyszczenie pola z godziną rozpoczęcia misji
            PassedData.finishString = null;//Wyczyszczenie pola z godziną zakończenia misji
            PassedData.slownik.Clear();//Wyczyszczenie zawartości słownika
            list.Items.Clear();//Wyczyszczenie listy z misjami specjalnymi
            lablist.Items.Clear();//Wyczyszczenie listy z misjami laboratoryjnymi
            fastlist.Items.Clear();//Wyczyszczenie listy z misjami błyskawicznymi
            */
            Frame.Navigate(typeof(MenuPage));//Przejście do poprzedniej strony, czyli do menu głównego
        }

        private async void logoutButton_Click(object sender, RoutedEventArgs e)//Naciśnięcie przycisku powoduje pojawienie się okna dialogowego z pytaniem o wylogowanie się z aplikacji
        {

            MessageDialog messageDialog = new MessageDialog(PassedData.askString);//Wyświetlenie treści komunikatu z pytaniem o wylogowanie się
            messageDialog.Commands.Add(new UICommand(PassedData.yesString, new UICommandInvokedHandler(CommandInvokedHandler)));//Dodanie przycisk z tekstem potwierdzający wylogowanie i obsługa po kliknięciu potwierdzającego wylogowanie
            messageDialog.Commands.Add(new UICommand(PassedData.noString));//Obsługa przy kliknięciu anulującego wylogowanie

            //Polecenie, które będzie wywołane jako potwierdzenie chęci wylogowania się z aplikacji 
            messageDialog.DefaultCommandIndex = 0;//0 dla opcji z CommandInvokedHandler

            //Polecenie, które będzie wywołane jako anulowanie chęci wylogowania się z aplikacji 
            messageDialog.CancelCommandIndex = 1;//1 dla drugiej opcji bez CommandInvokedHandler

            //Wywołanie okna z pytaniem
            await messageDialog.ShowAsync();
        }

        public void CommandInvokedHandler(IUICommand command)//Wywoływana gdy użytkownik potwierdzi chęć wylogowania się z aplikacji
        {
            /*
            PassedData.startString = null;//Wyczyszczenie pola z godziną rozpoczęcia misji
            PassedData.finishString = null;//Wyczyszczenie pola z godziną zakończenia misji
            PassedData.urlForQuestion = null;//Wyczyszczenie zawartości słownika
            PassedData.slownik.Clear();//Wyczyszczenie listy z misjami specjalnymi
            list.Items.Clear();//Wyczyszczenie listy z misjami laboratoryjnymi
            lablist.Items.Clear();//Wyczyszczenie listy z misjami błyskawicznymi
            fastlist.Items.Clear();
            */
            PassedData.LogOut = true;//Ustawienie flagi dla wylogowania użytkownika żeby wyświetlić komunikat o wylogowaniu się
            PassedData.isSelected = false;//Ustawienie domyślnej wartości flagi z wyborem motywu
            PassedData.chosenComboItem = null;////Ustawienie domyślnej wartości wybranego motywu
            PassedData.chosenTheme = "1";//Ustawienie domyślnej wartości motywu
            Frame.Navigate(typeof(MainPage));//Przeniesienie do strony logowania
        }
    }
}


