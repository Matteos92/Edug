﻿--------------------------------------
DANE TESTOWE
--------------------------------------

 do wszystkich aktywnych gier utworzono dodatkowe testowe konto o nastepujacych parametrach:
  adres email: edug@mailinator.com
  hasło      : Malinator
  hash (MD5) : 23e35b04cae83120eefb53ba336a6fba

 utworzono testową gre o kryptonimie 145tes
  można testowac na kontach:
   powyzszym o emailu: edug@mailinator.com  hasło: Malinator
   Pana o emailu:      matgrauman@gmail.com hasło: BSIBSI
--------------------------------------
--------------------------------------
HASŁO
--------------------------------------
 każdy z ważnych webserwisow wylicza crc zabezpieczone hasłem, crc wyliczone jako md5 od konkatenacji wszystkich argumentów poprzedzonych hasłem ($password)
 aktualnie $password = 'grauman'; hasło przechować tak aby łatwo je było w jednym miejscu kodu zmienić  
--------------------------------------
--------------------------------------
LOGOWANIE UŻYTKOWNIKA
--------------------------------------
 Opis    : logowanie użytkownika do konkretnej gry.
 EduG.pl : proces logowania i związane z nim ewentualne komunikaty błędów
 Nazwa   : user_login.php
 Parametry: 
  $sys  [pc,wp,io,an] 
  $lang [pl,en]
  $game   - identyfikator/kryptonim gry np. 145tes, 145bsi,
  $login  - adres email uzytkownika
  $hash   - skrót MD5 hasła użytkownika
  $crc    - suma kontrolna 
    $crc wyliczany jako md5($password.$sys.$lang.$game.$login.$hash)
	nieaktualne:
     crc przykład 0: md5(graumanwppl132bsiedug@mailinator.com23e35b04cae83120eefb53ba336a6fba) = #d8566817046555cca601211782fce7dc
     crc przykład 1: md5(graumanwppl145tesedug@mailinator.com23e35b04cae83120eefb53ba336a6fba) = #c2fb01403bb3b17d65958f6a6786c068
     crc przykład 2: md5(graumanwppl145tesmatgrauman@gmail.com5d61b33868329ec1d305daba428e2feb) = #bcbef1d73d2a3739f9e9daaaca89f58f

	 aktualnie:
	 crc przykład 0: md5(graumanwpplamw132bsiedug@mailinator.com23e35b04cae83120eefb53ba336a6fba) = #4af115281c9660772bb34c47fada2cd7
	 crc przykład 0: md5(graumanwpplamw145tesedug@mailinator.com23e35b04cae83120eefb53ba336a6fba) = #4d35e8207eabcd2e62684018b01bfecd
	 crc przykład 0: md5(graumanwpplamw145tesedug@mailinator.com23e35b04cae83120eefb53ba336a6fba) = #aae27733fdf474af72213f4b36c5df07

	 crc przykład 0: md5(Malinatorwpplamw145tesedug@mailinator.com23e35b04cae83120eefb53ba336a6fba) = #
	 graumanwpplamw145tesmatgrauman@gmail.com5d61b33868329ec1d305daba428e2feb
	 
 Przykład:
  https://www.edug.pl/_webservices/user_account.php?sys=wp&lang=pl&game=amw145tes&login=edug@mailinator.com&hash=23e35b04cae83120eefb53ba336a6fba&crc=4d35e8207eabcd2e62684018b01bfecd

  https://www.edug.pl/_webservices/user_account.php?sys=wp&lang=pl&game=amw145tes&login=matgrauman@gmail.com&hash=5d61b33868329ec1d305daba428e2feb&crc=aae27733fdf474af72213f4b36c5df07

 Przykład:
  http://www.edug.pl/_webservices/user_login.php?sys=wp&lang=pl&game=132bsi&login=edug@mailinator.com&hash=23e35b04cae83120eefb53ba336a6fba&crc=d8566817046555cca601211782fce7dc

  https://www.edug.pl/_webservices/user_login.php?sys=wp&lang=pl&game=amw132bsi&login=edug@mailinator.com&hash=23e35b04cae83120eefb53ba336a6fba&crc=4af115281c9660772bb34c47fada2cd7

  https://www.edug.pl/_webservices/user_login.php?sys=wp&lang=pl&game=amw145tes&login=edug@mailinator.com&hash=23e35b04cae83120eefb53ba336a6fba&crc=4d35e8207eabcd2e62684018b01bfecd
 
 Wynik:
   result [true, false]
   comment [(idu) - identyfikator użytkownika po poprawnym zalogowaniu, w pozostałych przypadkach komunikat błędu]
   {"user_login":{"result":true,"comment":"003"}}
   {"user_login":{"result":true,"comment":"123"}}
--------------------------------------
--------------------------------------
KONTO UŻYTKOWNIKA
--------------------------------------
 Opis    : Pobranie z bazy wszelkich aktualnych danych związanych z uzytkownikiem. 
 EduG.pl : te wartości które widac w prawym górnym rogu po zalogowaniu się do systemu
 Nazwa   : user_account.php
 Parametry: jak w LOGOWANIE UŻYTKOWNIKA

 Przykład:
  http://www.edug.pl/_webservices/user_account.php?sys=wp&lang=pl&game=145tes&login=edug@mailinator.com&hash=23e35b04cae83120eefb53ba336a6fba&crc=c2fb01403bb3b17d65958f6a6786c068

  http://www.edug.pl/_webservices/user_account.php?sys=wp&lang=pl&game=145tes&login=matgrauman@gmail.com&hash=5d61b33868329ec1d305daba428e2feb&crc=bcbef1d73d2a3739f9e9daaaca89f58f

 Wynik:
   jesli niepoprawne dane to: result [false] i comment [komunikat błędu]
   jesli poprawne dane to:    result [true]  i nastepujace dane: agent_number, agent_name, agent_email, count_bitcoin, count_avatar, count_exacoin, count_mission, count_point, lang

   {"user_account":
	{"result":true,
	"agent_number":"123",
	"agent_name":"GRAUMAN Mateusz",
	"agent_email":"matgrauman@gmail.com",
	"count_bitcoin":14,
	"count_avatar":1,
	"count_exacoin":28,
	"count_mission":0,
	"count_point":94,
	"count_badges_style":2,
	"lang":"pl"
	}
}
    
--------------------------------------
---------------------------------------
LISTA AKTYWNYCH GIER 
---------------------------------------
 Opis    : pobranie listy aktywnych gier do wyboru podczas logowania
 EduG.pl : te wartości które widac na liście rozwijanej strony startowej systemu (kryptonimy misji)
 Nazwa   : list_games.php
 
 Przykład: http://www.edug.pl/_webservices/list_games.php

 Wynik: lista kryptonimów aktywnych gier wraz ze statutem czy jest aktywna czy też nie

 Komentarz: tutaj nie ma zadnego zabezpieczenia hasłami i hashami
            w aplikacji wyświetlamy tylko aktywne gry

Przykład:

{"list_games":[
	{"game":{"idg":"amw145tes","active":"Y"}},
	{"game":{"idg":"amw_cyber","active":"N"}},
	{"game":{"idg":"amw155qo2","active":"N"}},
	{"game":{"idg":"amw155qo1","active":"N"}},
	{"game":{"idg":"amw145oij","active":"N"}},
	{"game":{"idg":"amw145bsi","active":"N"}},
	{"game":{"idg":"amw142bsi","active":"N"}},
	{"game":{"idg":"amw135oij","active":"N"}},
	{"game":{"idg":"amw135bsi","active":"N"}},
	{"game":{"idg":"amw132bsi","active":"N"}}
	]
}	 
---------------------------------------
---------------------------------------
LISTA MATERIAŁÓW / PLIKÓW 
---------------------------------------
 Opis    : pobranie listy materiałów pomocniczych (plików pdf, zip, doc, itp.)
 EduG.pl : lista plików umieszczona w niezbedniku Agenta, posegregowana na trzy kategorie [spec, labo, doda]
 Nazwa   : list_files.php
 Parametr: $idg - identyfikator/kryptonim gry 

 Przykład: http://www.edug.pl/_webservices/list_files.php?idg=145tes

 Wynik: lista plików wraz kategorią: {category, filename}

 Komentarz: tutaj nie ma zadnego zabezpieczenia hasłami i hashami
            w aplikacji segregujemy pliki zgodnie z przynależnościa do kategorii [spec, labo, doda]

			https:\/\/www.EduG.pl\/_sources\/amw145tes\/doda\/Raport_z_misji_laboratoryjnej.doc

---------------------------------------
---------------------------------------
LISTA AKTYWNYCH MISJI
---------------------------------------
 Opis    : pobranie listy wszystkich (nie tylko aktywnych) misji wraz z granicznymi datami ich trwania (start, stop)
 EduG.pl : lista misji umieszczona umieszczona z lewej strony systemu w Panelu Administracyjnym, posegregowana na kategorie [spec, labo, fast, hazd, last]
 Nazwa   : list_missions.php
 Parametr: $idg - identyfikator/kryptonim gry 

 Przykład: http://www.edug.pl/_webservices/list_missions.php?idg=145tes

 Wynik: lista: identyfikator misja, typ misji, data rozpoczecia, data zakonczenia {idm, type, start, stop}
 Uwaga:  dla misji hazardowej i ostatecznej zamiast identyfikatora (nie jest dla nich potrzebny) przekazywana jest liczba pytań w bazie dla danej misji - potrzebne do wyswietlenia w opisie misji 

 Komentarz: tutaj nie ma zadnego zabezpieczenia hasłami i hashami
            w aplikacji segregujemy misje zgodnie z przynależnościa do kategorii [spec, labo, fast, hazd, last]

{"list_missions":[
	{"mission":
		{"idm":"",
		"type":"hazd",
		"start":null,
		"stop":null}
	},
	{"mission":
		{"idm":"",
		"type":"last",
		"start":null,
		"stop":null
		}
	}]
}	 

---------------------------------------
---------------------------------------
OSIĄGNIĘCIA
---------------------------------------
 Opis    : pobranie listy wszystkich zdobytych punktów dla danego użytkwnika w danej grze
 EduG.pl : listy zdobytych punktów umieszczone w zakladce "Osiągnięcia", posegregowana na kategorie [spec, labo, fast, last]
 Nazwa   : extra_achievements.php
 Parametr: $idg - identyfikator/kryptonim gry 
           $idu - identyfikator użytkownika

 Przykład: http://www.edug.pl/_webservices/extra_achievements.php?idg=145tes&idu=123

 Wynik: lista: typ misji, identyfikator misji, kryptonim, zdobyte punkty

 Komentarz: tutaj nie ma zadnego zabezpieczenia hasłami i hashami
            w aplikacji segregujemy misje zgodnie z przynależnościa do kategorii [spec, labo, fast, last]

---------------------------------------
---------------------------------------
OBECNOŚCI
---------------------------------------
 Opis    : pobranie listy obecnosi na misjach dla danego użytkwnika w danej grze
 EduG.pl : listy obecności umieszczona w zakladce "Obecności", posegregowana na kategorie [spec, labo]
 Nazwa   : extra_attendances.php
 Parametr: $idg - identyfikator/kryptonim gry 
           $idu - identyfikator użytkownika

		   ,
 Przykład: http://www.edug.pl/_webservices/extra_attendances.php?idg=145tes&idu=123

 https://www.edug.pl/_webservices/extra_attendances.php?idg=amw145tes&idu=123

 Wynik: lista: typ zajęć [W-wyklad, L-laborka], data

 Komentarz: tutaj nie ma zadnego zabezpieczenia hasłami i hashami
            w aplikacji segregujemy misje zgodnie z przynależnościa do kategorii [spec, labo]

---------------------------------------
---------------------------------------
RANKINGI
---------------------------------------
 Opis    : pobranie list rankingowych
 EduG.pl : listy zdobytych punktów umieszczone w zakladce "Rankingi", posegregowana na kategorie [spec, labo, fast, full]
 Nazwa   : extra_leaderboards.php
 Parametr: $idg - identyfikator/kryptonim gry 

 Przykład: http://www.edug.pl/_webservices/extra_leaderboards.php?idg=145tes

 Wynik: lista: typ misji, identyfikator agenta, email agenta, zdobyte punkty

 Komentarz: tutaj nie ma zadnego zabezpieczenia hasłami i hashami
            w aplikacji segregujemy misje zgodnie z przynależnościa do kategorii [spec, labo, fast, full]
            email agenta potrzebny do wyswietlenia gravatara

---------------------------------------
--------------------------------------
MISJA BŁYSKAWICZNA
--------------------------------------
 Opis    : obsługa misji błyskawicznej, ten sam plik 
 EduG.pl : tak jak po wybraniu konkretnej misji błyskawicznej z Menu
 Nazwa   : mission_fast.php
 Parametry: 
  $sys  [pc,wp,io,an] 
  $lang [pl,en]
  $game   - identyfikator/kryptonim gry np. 145tes, 145bsi,
  $mission- identyfikator misji np. 103, 110
  $answer - udzielana odpowiedz, na przykład słowo ANANAS, gdy pobieramy tylko pytanie $answer = ''; [pole opcjonalne przy pobieraniu pytania, obowiazkowe przy udzielaniu odpowiedzi]
  $login  - adres email uzytkownika
  $hash   - skrót MD5 hasła użytkownika
  $crc    - suma kontrolna 
    $crc wyliczany jako md5($password.$sys.$lang.$game.$mission.$answer.$login.$hash)
     crc przykład pobranie pytania: md5(graumanwppl145tes103edug@mailinator.com23e35b04cae83120eefb53ba336a6fba) = #fedc9ea3b22f5668a71372fdf521ba48
     crc przykład odzielenie odpow: md5(graumanwppl145tes103ANANASedug@mailinator.com23e35b04cae83120eefb53ba336a6fba) = #1bbd9350d5a701eb6b5f044ad3a6c0a8

 Przykład:
  pobranie pyt: http://www.edug.pl/_webservices/mission_fast.php?sys=wp&lang=pl&game=145tes&mission=103&login=edug@mailinator.com&hash=23e35b04cae83120eefb53ba336a6fba&crc=fedc9ea3b22f5668a71372fdf521ba48
  odpowiedz: http://www.edug.pl/_webservices/mission_fast.php?sys=wp&lang=pl&game=145tes&mission=103&answer=ANANAS&login=edug@mailinator.com&hash=23e35b04cae83120eefb53ba336a6fba&crc=1bbd9350d5a701eb6b5f044ad3a6c0a8

  https://www.edug.pl/_webservices/user_account.php?sys=wp&lang=pl&game=amw145tes&login=matgrauman@gmail.com&hash=5d61b33868329ec1d305daba428e2feb&crc=aae27733fdf474af72213f4b36c5df07

  {"mission_fast":{"result":false,"comment":"Misja zako\u0144czona ."}}

 Wynik:
   result [true, false]
     true  - jesli misja jest dostepna (aktywna, nie udzielono jeszcze na nia odpowiedzi), wowczas podawane sa wszystkie parametry pytania (daty, komentarze przed i po, tresc pytania)
     false - w każdym innym przypadku, wowczas podawany jest komentarz błędu - comment

--------------------------------------
--------------------------------------
MISJA LABORATORYJNA
--------------------------------------
 Opis    : informacja o misji laboratoryjnej, bez możliwości uploadu pliku (na razie ;-) zobaczymy czy jest sens to wprowadzać 
 EduG.pl : tak jak po wybraniu konkretnej misji laboratoryjnej z Menu
 Nazwa   : mission_labo.php
 Parametry: 
  $sys  [pc,wp,io,an] 
  $lang [pl,en]
  $game   - identyfikator/kryptonim gry np. 145tes, 145bsi,
  $mission- identyfikator misji np. 203, 208
  $login  - adres email uzytkownika
  $hash   - skrót MD5 hasła użytkownika
  $crc    - suma kontrolna 
    $crc wyliczany jako md5($password.$sys.$lang.$game.$mission.$login.$hash)
     crc przykład: md5(graumanwppl145tes203edug@mailinator.com23e35b04cae83120eefb53ba336a6fba) = #966e2f64127360f4516f59924dc574b1

 Przykład: http://www.edug.pl/_webservices/mission_labo.php?sys=wp&lang=pl&game=145tes&mission=203&login=edug@mailinator.com&hash=23e35b04cae83120eefb53ba336a6fba&crc=966e2f64127360f4516f59924dc574b1
	   http://www.edug.pl/_webservices/mission_labo.php?sys=wp&lang=pl&game=145tes&mission=205&login=edug@mailinator.com&hash=23e35b04cae83120eefb53ba336a6fba&crc=057f0afd06849547f0a001da9fe41012
 
 Wynik:
   result [true, false]
     true  - jesli misja jest dostepna (aktywna, nie udzielono jeszcze na nia odpowiedzi), wowczas podawane sa wszystkie parametry (daty, plik, komentarz)
     false - w każdym innym przypadku, wowczas podawany jest komentarz błędu - comment

--------------------------------------
--------------------------------------
MISJA SPECJALNA
--------------------------------------
 Opis    : pełna obsługa misji specjalnej 
 EduG.pl : tak jak po wybraniu konkretnej misji specjalnej z Menu
 Nazwa   : mission_spec.php
 Parametry: 
  $sys  [pc,wp,io,an] 
  $lang [pl,en]
  $game   - identyfikator/kryptonim gry np. 145tes, 145bsi,
  $mission- identyfikator misji np. 303, 308
  $answerN- odpowiedz na pytanie N [pole opcjonalne przy pobieraniu pytania, obowiazkowe przy udzielaniu odpowiedzi]
  $login  - adres email uzytkownika
  $hash   - skrót MD5 hasła użytkownika
  $crc    - suma kontrolna
    $crc wyliczany jako md5($password.$sys.$lang.$game.$mission.$answer1.$answer2.$answer3.$answer4.$login.$hash)
     crc przykład pobranie pytania: md5(graumanwppl145tes308edug@mailinator.com23e35b04cae83120eefb53ba336a6fba) = #a57048b52c277706299f235eb9f428a6
     crc przykład odzielenie odpow: md5(grauman wp pl 145tes 308 3 21 1243 41 edug@mailinator.com 23e35b04cae83120eefb53ba336a6fba) = #77d59a958199991ea00a8ce6b2f8e5e1

 Przykład:
  pobranie pyt: http://www.edug.pl/_webservices/mission_spec.php?sys=wp&lang=pl&game=145tes&mission=308&login=edug@mailinator.com&hash=23e35b04cae83120eefb53ba336a6fba&crc=a57048b52c277706299f235eb9f428a6
  odpowiedz: http://www.edug.pl/_webservices/mission_spec.php?sys=wp&lang=pl&game=145tes&mission=308&answer1=3&answer2=21&answer3=1243&answer4=41&login=edug@mailinator.com&hash=23e35b04cae83120eefb53ba336a6fba&crc=77d59a958199991ea00a8ce6b2f8e5e1

 Wynik:
   result [true, false]
     true  - jesli misja jest dostepna (aktywna, nie udzielono jeszcze na nia odpowiedzi), wowczas podawane sa wszystkie parametry pytania (daty, komentarze przed i po, tresc pytan i mozliwe odpowiedzi)
     false - w każdym innym przypadku, wowczas podawany jest komentarz błędu - comment

 Uwaga:
   mozliwe odpowiedzi na pytania nalezy posortowac losowo przed wyswietleniem graczowi
--------------------------------------
--------------------------------------
MISJA OSTATECZNA - NA RAZIE JESZCZE NIE DZIALA !!!
--------------------------------------
 Opis    : pełna obsługa misji ostatecznej, czyli egzaminu/kolokwium 
 EduG.pl : tak jak po wybraniu Misji Ostatecznej z Menu
 Nazwa   : mission_last.php
 Parametry: 
  $sys  [pc,wp,io,an] 
  $lang [pl,en]
  $game   - identyfikator/kryptonim gry np. 145tes, 145bsi
  $mission- identyfikator misji np. 403, 448 [pole opcjonalne przy pobieraniu pytania, obowiazkowe przy udzielaniu odpowiedzi]
  $answer - odpowiedz na pytanie             [pole opcjonalne przy pobieraniu pytania, obowiazkowe przy udzielaniu odpowiedzi]
  $login  - adres email uzytkownika
  $hash   - skrót MD5 hasła użytkownika
  $crc    - suma kontrolna
    $crc wyliczany jako md5($password.$sys.$lang.$game.$mission.$answer.$login.$hash)
     crc przykład pobranie pytania: md5(graumanwppl145tesedug@mailinator.com23e35b04cae83120eefb53ba336a6fba) = #a57048b52c277706299f235eb9f428a6
     crc przykład odzielenie odpow: md5(graumanwppl145tes448321edug@mailinator.com23e35b04cae83120eefb53ba336a6fba) = #77d59a958199991ea00a8ce6b2f8e5e1

 Przykład:
  pobranie pyt: http://www.edug.pl/_webservices/mission_last.php?sys=wp&lang=pl&game=145tes&login=edug@mailinator.com&hash=23e35b04cae83120eefb53ba336a6fba&crc=a57048b52c277706299f235eb9f428a6
  odpowiedz: http://www.edug.pl/_webservices/mission_last.php?sys=wp&lang=pl&game=145tes&mission=408&answer=32&login=edug@mailinator.com&hash=23e35b04cae83120eefb53ba336a6fba&crc=77d59a958199991ea00a8ce6b2f8e5e1
  odpowiedz: http://www.edug.pl/_webservices/mission_hazd.php?sys=wp&lang=pl&game=amw145tes&mission=463&answer=4&login=matgrauman@gmail.com&hash=5d61b33868329ec1d305daba428e2feb&crc=dbfc3958b5d02171a5b0826452147a94

 Wynik:
   result [true, false]
     true  - jesli misja jest dostepna (aktywna, nie udzielono jeszcze na nia odpowiedzi), wowczas podawane sa wszystkie parametry pytania (daty, komentarze przed i po, tresc pytan i mozliwe odpowiedzi)
     false - w każdym innym przypadku, wowczas podawany jest komentarz błędu - comment

--------------------------------------
---------------------------------------
ODZNACZENIA
---------------------------------------
 Opis    : pobranie listy osišgnięć/odznak
 EduG.pl : lista odznak umieszczona w zakladce "Odznaczenia"
 Nazwa   : extra_badges.php
 Parametr: $idg - identyfikator/kryptonim gry 
           $idu - identyfikator użytkownika
	   $lang [pl,en]

 Przykład: https://www.edug.pl/_webservices/extra_badges.php?lang=pl&idg=amw145tes&idu=123
           https://www.edug.pl/_webservices/extra_badges.php?lang=pl&idg=amw145tes&idu=003

 Wynik: lista: name, perc, file, desc (nazwa odznaki, procent zdobycia, plik graficzny, opis jak zdobyć)

 Komentarz: tutaj nie ma zadnego zabezpieczenia hasłami i hashami
            pliki graficzne odznak umieszczone sš w lokalizacji https://www.EduG.pl/_odznaki/<numer motywu>/<nazwa pliku>
						    na przyklad https://www.EduG.pl/_odznaki/2/odz_spec.png

 Uwaga: numer motywu jest liczbš od jeden do "count_badges_style" pobranym w webserwisie user_account.php
        domylmnie przyjmowany ma być motyw numer 1, ale w aplikacji ma byc możliwoc zmienienia tego motywu

---------------------------------------