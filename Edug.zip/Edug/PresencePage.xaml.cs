﻿using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.Net.Http;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace Edug
{
    public sealed partial class PresencePage : Page
    {
        public PresencePage()
        {
            this.InitializeComponent();  
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)//Gdy strona jest aktywna
        {
            setLanguage();//Ustawia wyświetlanego tekstu według języka agenta
            Functions.Function.getInfo();//Aktualizuje informacje nt. zdobytych punktów przez agenta w belce na dole ekranu
            setAppBar();//Ustawia wartości zdobytych punktów przez agenta
            getAttendance();//Metoda do pobrania misji
        }

        public string idg = PassedData.group, idu = PassedData.agent_number;//Globalne zmienne, która zmienna "idg" przyjmuje za wartość kryptonim gry, a zmienna "idu" przyjmuje identyfikator agenta

        public void setLanguage()//Wyświetla tekst według języka agenta
        {
            switch (PassedData.lang)
            {
                case "pl":
                    pivot_account.Header = "Specjalne";
                    pivot_items.Header = "Laboratoryjne";
                    backButton.Label = "Powrót";
                    logoutButton.Label = "Wyloguj";
                    break;
                case "en":
                    pivot_account.Header = "Special";
                    pivot_items.Header = "Laboratory";
                    backButton.Label = "Back";
                    logoutButton.Label = "Logout";
                    break;
            }
        }

        public async void getAttendance()//Uzyskuje listę wszystkich obecności agenta na zajęciach
        {
            try
            {
                using (HttpClient client = new HttpClient())//Utworzenie klienta http w celu obsługi adresu url
                {
                    string link = @"https://www.edug.pl/_webservices/extra_attendances.php?idg=" + idg + "&idu=" + idu;//idg - identyfikator gry agenta, idu - identyfikator agenta
                    var uri = new Uri(link);//Inicjowanie nowej instacji klasy Uri z podanym adresem strony
                    client.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;//Sprawdzenie czy zaszła zmiana od ostatniego żądania do serwera od momentu wysłania zapytania
                    var Response = await client.GetAsync(uri);//Wysyła żądanie GET dla danego odnosnika URL
                    var statusCode = Response.StatusCode;//Rezultat i kod
                    Response.EnsureSuccessStatusCode();
                    //Jeśli odpowiedź jest inna od Http 200
                    //wtedy metoda EnsureSuccessStatusCode wyrzuci wyjątek
                    var ResponseText1 = await Response.Content.ReadAsStringAsync();//Pobranie asynchronicznie odpowiedzi od serwera
                    client.CancelPendingRequests();//Anulowanie wszelkich żądań do serwera
                    client.Dispose();//Zamknięcie klienta
                    getVisit(ResponseText1);//Uzyskiwanie listy obecności agenta
                }
            }
            catch (Exception ex)//Przy pojawieniu się wyjątku, treść błędu jest wyświetlana w konsoli
            {
                Debug.WriteLine(ex);
            }
        }

        public void getVisit(string edata)//Segreguje misje według kategorii
        {
            Classes.RootObject obj = JsonConvert.DeserializeObject<Classes.RootObject>(edata);//Przetworzenie pliku json do typu .NET
            int licznik = obj.extra_attendances.Count;//Liczba wszystkich obecności

            for (int i = 0; i < licznik; i++)
            {
                var item = new Classes.Mission();//Utworzenie obiektu jako nowej instacji klasy Mission 
                string type = obj.extra_attendances[i].mission.type;//Typ zajęć
                string data = obj.extra_attendances[i].mission.data;//Data kiedy zajęcia odbyły się
                if(type == "W")//Gdy typ zajęć to wykład
                {
                    item.data = data;//Zapisanie do obiektu daty
                    item.type = type;//Zapisanie do obiektu typu zajęć
                    list.Items.Add(item);//Dodanie obiektu do listy z obecnościami na wykładach, gdzie zostanie wyświetlony
                }
                else//Gdy typ zajęć to zajęcia laboratoryjne
                {
                    item.data = data;//Zapisanie do obiektu daty
                    item.type = type;//Zapisanie do obiektu typu zajęć
                    lablist.Items.Add(item);//Dodanie obiektu do listy z obecnościami na zajęciach laboratoryjnych, gdzie zostanie wyświetlony
                }
            }
        }

        private void button_Click(object sender, RoutedEventArgs e)//Naciśnięcie przycisku powoduje powrót do poprzedniej strony
        {
            Frame.Navigate(typeof(MenuPage));//Przejście do poprzedniej strony, czyli do menu głównego
        }

        private async void logoutButton_Click(object sender, RoutedEventArgs e)//Naciśnięcie przycisku powoduje pojawienie się okna dialogowego z pytaniem o wylogowanie się z aplikacji
        {
            MessageDialog messageDialog = new MessageDialog(PassedData.askString);//Wyświetlenie treści komunikatu z pytaniem o wylogowanie się
            messageDialog.Commands.Add(new UICommand(PassedData.yesString, new UICommandInvokedHandler(CommandInvokedHandler)));//Dodanie przycisk z tekstem potwierdzający wylogowanie i obsługa po kliknięciu potwierdzającego wylogowanie
            messageDialog.Commands.Add(new UICommand(PassedData.noString));//Dodanie przycisk z tekstem anulujący wylogowanie się

            //Polecenie, które będzie wywołane jako potwierdzenie chęci wylogowania się z aplikacji 
            messageDialog.DefaultCommandIndex = 0;//Dla opcji obsługującej wylogowanie 

            //Polecenie, które będzie wywołane jako anulowanie chęci wylogowania się z aplikacji 
            messageDialog.CancelCommandIndex = 1;//Dla drugiej opcji anulującej wylogowanie

            //Wywołanie okna dialogowego
            await messageDialog.ShowAsync();
        }

        public void CommandInvokedHandler(IUICommand command)//Gdy użytkownik potwierdzi chęć wylogowania się z aplikacji
        {
            PassedData.LogOut = true;//Ustawienie flagi dla wylogowania użytkownika żeby wyświetlić komunikat o wylogowaniu się
            PassedData.isSelected = false;//Ustawienie domyślnej wartości flagi z wyborem motywu
            PassedData.chosenComboItem = null;////Ustawienie domyślnej wartości wybranego motywu
            PassedData.chosenTheme = "1";//Ustawienie domyślnej wartości motywu
            Frame.Navigate(typeof(MainPage));//Przeniesienie do strony logowania
        }

        public void setAppBar()//Wyświetla tekst i wartość przycisków na belce w dolnej części ekranu
        {
            AvatarAddAppBarButton.Label = PassedData.count_avatar + PassedData.countAvatarString;//Tekst i ilość zdobytych avatarów
            BitcoinAddAppBarButton.Label = PassedData.count_bitcoin + PassedData.countBitcoinString;//Tekst i ilość zdobytych bitcoinów
            ExacoinAddAppBarButton.Label = PassedData.count_exacoin + PassedData.countExacoinString;//Tekst i ilość zdobytych exacoinów
            PointsAddAppBarButton.Label = PassedData.count_point + PassedData.countPointString;//Tekst i ilość zdobytych punktów
        }
    }
}

