﻿using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.Net.Http;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace Edug
{
    public sealed partial class DecorationsPage : Page
    {
        public DecorationsPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            PassedData.slownik.Clear();//Wyczyszczenie słownika z wartości
            Functions.Function.getInfo();//funkcja do aktualizacji informacji nt. zdobytych punktów przez agenta
            setLanguage();
            setAppBar();
            getDecorations();
        }

        public void setLanguage()//Ustawia wyświetlany tekst według języka
        {
            switch (PassedData.lang)
            {
                case "pl":
                    BackButton.Label = "Powrót";
                    LogoutButton.Label = "Wyloguj";
                    break;
                case "en":
                    BackButton.Label = "Back";
                    LogoutButton.Label = "Log out";
                    break;
            }
        }

        public void setAppBar()//Ustawia treść i wartość przycisków na belce na dolnej części ekranu
        {
            AvatarAddAppBarButton.Label = PassedData.count_avatar + PassedData.countAvatarString;//Treść i wartość dla avatarów
            BitcoinAddAppBarButton.Label = PassedData.count_bitcoin + PassedData.countBitcoinString;//Treść i wartość dla bitcoinów
            ExacoinAddAppBarButton.Label = PassedData.count_exacoin + PassedData.countExacoinString;//Treść i wartość dla exacoinów
            PointsAddAppBarButton.Label = PassedData.count_point + PassedData.countPointString;//Treść i wartość dla punktów
        }

        public async void getDecorations()//Funkcja która pobiera ikony do odznaczeń
        {
            //Język, identyfikator gry i agenta są pobierane z klasy PassedData.cs
            string lang = PassedData.lang; //Język agenta
            string idg = PassedData.group; //Identyfikator gry agenta
            string idu = PassedData.agent_number; //Identyfikator agenta
            string url = @"https://www.edug.pl/_webservices/extra_badges.php?lang="+ lang + "&idg="+ idg + "&idu="+ idu; //adres url z ikonami
            try
            {
                //Utworzenie klienta http
                using (HttpClient client = new HttpClient())
                {
                    //Definiowanie URL
                    Uri uri = new Uri(url);
                    client.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;
                    //Wywołanie oraz pobranie asynchronicznie odpowiedzi 
                    var Response = await client.GetAsync(uri);
                    //Odpowiedź i kod statusu
                    var statusCode = Response.StatusCode;
                    //Jeśli kod statusu jest inny niż 200 wtedy proces EnsureSuccessStatusCode wyrzuci wyjątek 
                    Response.EnsureSuccessStatusCode();
                    //Czytanie zawartości odpowiedzi
                    //Tutaj spodziewaną odpowiedzią jest ciąg znaków
                    string ResponseText1 = await Response.Content.ReadAsStringAsync();
                    client.CancelPendingRequests();//anuluje wszystkie oczekujące żądania
                    client.Dispose();// zbywa zarządzane zasoby
                    getDecoration(ResponseText1);//wywołanie funkcji do obsługi zawartości odpowiedzi
                }     
            }
            catch (Exception ex)//Przy pojawieniu się wyjątku, treść błędu jest wyświetlana w konsoli
            {
                Debug.WriteLine(ex);
            }
        }

        public void getDecoration(string data)
        {
            Classes.RootObject obj = JsonConvert.DeserializeObject<Classes.RootObject>(data);//zmienna gdzie konwertuje się zawartość odpowiedzi serwera z pliku .json

            int licznik = obj.extra_badges.Count; //liczba odznaczeń

            for (int i = 0;i< licznik;i++)
            {
                var item = new Classes.Badge(); //tworzenie instancji klasy odznaczenia

                item.name = obj.extra_badges[i].badge.name.ToString(); //nazwa odznaczenia
                item.desc = obj.extra_badges[i].badge.desc.ToString(); //opis odznaczenia
                /*
                 Jeśli wartość procentowa postępów agenta jest poniżej 100%, jest wyświetlany pasek ProgressBar,
                 w przeciwnym przypadku jest wyświetlane odznaczenie.
                 */
                if (Int32.Parse(obj.extra_badges[i].badge.perc)<100) //Int32.Parse konwertuje ciąg reprezentujący liczbę na jego 32-bitową wersję liczby całkowitej
                {
                    item.valu = Int32.Parse(obj.extra_badges[i].badge.perc); //wartość dla paska ProgressBara
                    item.see = "Visible"; //jest widoczny pasek ProgressBara
                }
                else
                {
                    item.see = "Collapsed"; //nie jest widoczny pasek ProgressBara, wyświetlana jest ikona odznaczenia
                    item.file = loadImage(obj.extra_badges[i].badge.file.ToString()); //odnośnik do odznaczenia
                }
                item.perc = obj.extra_badges[i].badge.perc + " %";
                filemane = item.name;
                location = item.desc;
                PassedData.slownik.Add(filemane, location);//dodawanie nazwy odznaczenia jako klucz, opisu jako wartość
                list.Items.Add(item); // wszystkie pola są dodawanie do ListView o nazwie list, po ukończenia wykonywania funkcji wyświetlane są na stronie
            }
        }//Funkcja do przetworzenia odpowiedzi od serwera

        public string category, filemane, location;//Pomocnicze stringi dla kategorii, nazwy pliku oraz lokalizacji pliku

        public void list_SelectionChanged(object sender, RoutedEventArgs e)//Funkcja, która służy do wyświetlania komunikatu z treścią opisu danego odznaczenia
        {
            /* korzysta z słownika, który jako klucz jest nazwa ikony, wartością opis ikony */
            Classes.Badge myobject = (sender as ListView).SelectedItem as Classes.Badge;
            if (myobject != null)
            {
                string value, key = myobject.name;
                if (PassedData.slownik.ContainsKey(key))//jeśli w słowniku jest dany klucz
                {
                    value = PassedData.slownik[key]; //zwraca wartość
                    Functions.Function.showMessage(value); //wyświetla opis odznaczenia w komunikacie
                }
            }
        }

        private string loadImage(string name)//Zwraca odnośnik do pobrania ikony odznaczenia
        {
            string number = PassedData.chosenTheme; //numer motywu ustawia ikonę odznaczenia, numer można zmienić, zmieniając motyw
            Uri myUri = new Uri("https://www.EduG.pl/_odznaki/" + number + "/"+name, UriKind.Absolute);           
            return myUri.ToString();
        }

        private void backButton_Click(object sender, RoutedEventArgs e)
        {
            PassedData.slownik.Clear();
            Frame.Navigate(typeof(MenuPage));
        }//Wyczyszczenie zawartości słownika, nastepnie powrót do strony poprzedniej

        private async void logoutButton_Click(object sender, RoutedEventArgs e)//Funkcja po kliknięciu przycisku do wylogowania
        {
            MessageDialog messageDialog = new MessageDialog(PassedData.askString);//Wyświetlenie treści komunikatu z pytaniem o wylogowanie się
            messageDialog.Commands.Add(new UICommand(PassedData.yesString, new UICommandInvokedHandler(CommandInvokedHandler)));//Dodanie i obsługa przy kliknięciu potwierdzającego wylogowanie
            messageDialog.Commands.Add(new UICommand(PassedData.noString));//Dodanie i obsługa przy kliknięciu anulującego wylogowanie

            //Ustawiona komenda, która będzie domyślnie wywoływana
            messageDialog.DefaultCommandIndex = 0;

            //Ustawione polecenie, które ma zostać wywołane po naciśnięciu klawisza escape
            messageDialog.CancelCommandIndex = 1;

            //Pokazanie okna z zapytaniem o wylogowanie się
            await messageDialog.ShowAsync();
        }

        public void CommandInvokedHandler(IUICommand command)//Wywoływana funkcja gdy użytkownik potwierdzi wylogowanie się z aplikacji
        {
            PassedData.slownik.Clear();//wyczyszczenie zawartości słownika
            PassedData.LogOut = true;//ustawienie flagi dla wylogowania użytkownika żeby wyświetlić komunikat o wylogowaniu się
            PassedData.isSelected = false;//ustawienie domyślnej wartości flagi wybranej pozycji z comboBoxa
            PassedData.chosenComboItem = null;//ustawienie domyślnej wartości zapamiętanej pozycji z comboBoxa
            PassedData.chosenTheme = "1";//ustawienie domyślnej wartości motywu
            Frame.Navigate(typeof(MainPage));//przeniesienie do strony logowania
        }
    }
}








