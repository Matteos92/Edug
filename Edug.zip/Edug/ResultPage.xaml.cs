﻿using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.Net.Http;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace Edug
{
    public sealed partial class ResultPage : Page
    {
        public ResultPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)//Gdy strona jest aktywna
        {
            setLanguage();
            Functions.Function.getInfo();//Aktualizuje informacje dot. zdobytych punktów przez agenta w belce na dole ekranu
            setAppBar();
            getAchievements();
        }

        public async void getAchievements()//Uzyskuje listę wszystkich wyników agenta
        {
            string ResponseText1;//pomocniczna zmienna lokalna, do niej zapisana jest odpowiedź od webserwera
            string group = PassedData.group, idu = PassedData.agent_number;//Lokalne zmienne, która zmienna "group" przyjmuje za wartość kryptonim gry, a zmienna "idu" przyjmuje identyfikator agenta
            try
            { 
                using (HttpClient client = new HttpClient())//Utworzenie klienta http w celu obsługi adresu url
                {
                    string link = @"https://www.edug.pl/_webservices/extra_achievements.php?idg=" + group + "&idu=" + idu;//Tworzenie adresu url
                    var uri = new Uri(link);//Inicjowanie nowej instacji klasy Uri z podanym adresem strony
                    client.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;//Sprawdzenie czy zaszła zmiana od ostatniego żądania do serwera od momentu wysłania zapytania
                    var Response = await client.GetAsync(uri);//Wysyła żądanie GET dla danego odnośnika URL
                    var statusCode = Response.StatusCode;//Rezultat i kod http
                    Response.EnsureSuccessStatusCode();
                    //Jeśli odpowiedź jest inna od Http 200
                    //wtedy metoda EnsureSuccessStatusCode wyrzuci wyjątek
                    ResponseText1 = await Response.Content.ReadAsStringAsync();//Pobranie asynchronicznie odpowiedzi od webserwera
                    client.CancelPendingRequests();//Anulowanie wszelkich żądań do serwera
                    client.Dispose();//Zamknięcie klienta
                    getAchieve(ResponseText1);//Uzyskiwanie listy z wynikami agenta
                }
            }
            catch (Exception ex)//Przy pojawieniu się wyjątku, treść błędu jest wyświetlana w konsoli
            {
                Debug.WriteLine(ex);
            }
        }

        public void getAchieve(string edata)//Segreguje wyniki według kategorii
        {
            Classes.RootObject obj = JsonConvert.DeserializeObject<Classes.RootObject>(edata);//Przetworzenie pliku json do typu.NET
            int licznik = obj.extra_achievements.Count;//Liczba wszystkich wyników
            int punkty, specwynik = 0, labwynik = 0, fastwynik = 0, finalwynik = 0;//pomocniczne zmienne do obliczania sumy zdobytych punktów według kategorii misji
            for (int i = 0; i < licznik; i++)
            {
                var item = new Classes.Mission();//Utworzenie obiektu jako nowej instacji klasy Mission 
                string idm = obj.extra_achievements[i].mission.idm;//Identyfikator misji
                string codename = obj.extra_achievements[i].mission.codename;//Kryptonim misji
                string points = obj.extra_achievements[i].mission.points;//Liczba zdobytych punktów
                string point;
                //Gdy punkty mają wartość null a trzeba je wyświetlić
                if (points==null)
                {
                    points = "0";//Do wyświetlenia
                    point = "";//Do działań
                }
                else
                {
                    point = points;
                }
                string type = obj.extra_achievements[i].mission.type;//Kategoria misji
                switch (type)//Dodanie do listy według kategorii misji
                {
                    case "spec"://Do misji specjalnej
                        item.idm = idm;//Zapisanie do obiektu identyfikatora misji
                        item.codename = codename;//Zapisanie do obiektu kyptonimu misji
                        item.points = point;//Zapisanie do obiektu liczbę zdobytych punktów
                        list.Items.Add(item);//Dodanie obiektu do listy wyników dla misji specjalnej, gdzie zostanie wyświetlony
                        punkty = int.Parse(points);//Parsowanie typu z stringa na integer
                        specwynik = specwynik + punkty;//Dodanie punktów do sumy
                        PunktyTextBlock.Text = specwynik.ToString();//Zapisanie do zmiennej sumy zdobytych punktów, która zostanie wyświetlona na dole tabelki z wynikami dla misji specjalnej
                        break;
                    case "labo"://Do misji laboratoryjnej
                        item.idm = idm;
                        item.codename = codename;
                        item.points = point;
                        lablist.Items.Add(item);//Dodanie obiektu do listy wyników dla misji laboratoryjnej, gdzie zostanie wyświetlony
                        punkty = int.Parse(points);
                        labwynik += punkty;
                        PunktyLabTextBlock.Text = labwynik.ToString();//Zapisanie do zmiennej sumy zdobytych punktów, która zostanie wyświetlona na dole tabelki z wynikami dla misji laboratoryjnej
                        break;
                    case "fast"://Do misji błyskawicznej
                        item.idm = idm;
                        item.codename = codename;
                        item.points = point;
                        fastlist.Items.Add(item);//Dodanie obiektu do listy wyników dla misji błyskawicznej, gdzie zostanie wyświetlony
                        punkty = int.Parse(points);
                        fastwynik += punkty;
                        PunktyFastTextBlock.Text = fastwynik.ToString();//Zapisanie do zmiennej sumy zdobytych punktów, która zostanie wyświetlona na dole tabelki z wynikami dla misji błyskawicznej
                        break;
                    case "last"://Do misji ostatecznej
                        item.idm = idm;
                        item.codename = codename;
                        item.points = point;
                        finallist.Items.Add(item);//Dodanie obiektu do listy wyników dla misji ostatecznej, gdzie zostanie wyświetlony
                        punkty = int.Parse(points);
                        finalwynik += punkty;
                        PunktyfinalTextBlock.Text = finalwynik.ToString();//Zapisanie do zmiennej sumy zdobytych punktów, która zostanie wyświetlona na dole tabelki z wynikami dla misji ostatecznej
                        break;
                    default://Gdy wynik nie należy do żadnej kategorii
                        break;
                }
            }
        }

        public void setLanguage()//Wyświetla tekst według języka agenta
        {
            string codename, points, specHeader, labHeader, fastHeader, finalHeader;//Pomocniczne zmienne lokalne dla kryptonimu, punktów i nagłówków
            switch (PassedData.lang)//Tekst na stronie jest wyświetlany w zależności od języka
            {
                case "pl"://W języku polskim
                    codename = "KRYPTONIM"; points = "PKT";
                    backButton.Label = "Powrót";
                    logoutButton.Label = "Wyloguj";
                    specHeader = "Specjalne";
                    labHeader = "Laboratoryjne";
                    fastHeader = "Błyskawiczne";
                    finalHeader = "Ostateczna";
                    pivot_specjal.Header = specHeader;
                    spCryptTextBlock.Text = codename;
                    spPointTextBlock.Text = points;
                    pivot_lab.Header = labHeader;
                    labCryptTextBlock.Text = codename;
                    labPointTextBlock.Text = points;
                    pivot_fast.Header = fastHeader;
                    fastCryptTextBlock.Text = codename;
                    fastPointTextBlock.Text = points;
                    pivot_final.Header = finalHeader;
                    finCryptTextBlock.Text = codename;
                    finPointTextBlock.Text = points;
                    WynikfinalTextBlock.Text = "Wynik:";
                    PunktyfinalTextBlock.Text = "Punkty";
                    break;
                case "en"://W języku angielskim
                    codename = "CODENAME"; points = "PKT";
                    backButton.Label = "Back";
                    logoutButton.Label = "Logout";
                    specHeader = "Special";
                    labHeader = "Lab";
                    fastHeader = "Fast";
                    finalHeader = "Final";
                    pivot_specjal.Header = specHeader;
                    spCryptTextBlock.Text = codename;
                    spPointTextBlock.Text = points;
                    pivot_lab.Header = labHeader;
                    labCryptTextBlock.Text = codename;
                    labPointTextBlock.Text = points;
                    pivot_fast.Header = fastHeader;
                    fastCryptTextBlock.Text = codename;
                    fastPointTextBlock.Text = points;
                    pivot_final.Header = finalHeader;
                    finCryptTextBlock.Text = codename;
                    finPointTextBlock.Text = points;
                    WynikfinalTextBlock.Text = "Score:";
                    PunktyfinalTextBlock.Text = "points";
                    break;
            }
        }

        public void setAppBar()//Wyświetla tekst i wartość przycisków na belce w dolnej części ekranu
        {
            AvatarAddAppBarButton.Label = PassedData.count_avatar + PassedData.countAvatarString;//Tekst i ilość zdobytych avatarów
            BitcoinAddAppBarButton.Label = PassedData.count_bitcoin + PassedData.countBitcoinString;//Tekst i ilość zdobytych bitcoinów
            ExacoinAddAppBarButton.Label = PassedData.count_exacoin + PassedData.countExacoinString;//Tekst i ilość zdobytych exacoinów
            PointsAddAppBarButton.Label = PassedData.count_point + PassedData.countPointString;//Tekst i ilość zdobytych punktów
        }

        private void backButton_Click(object sender, RoutedEventArgs e)//Naciśnięcie przycisku powoduje powrót do poprzedniej strony
        {
            Frame.Navigate(typeof(MenuPage));//Przejście do poprzedniej strony, czyli do menu głównego
        }

        private async void logoutButton_Click(object sender, RoutedEventArgs e)//Naciśnięcie przycisku powoduje pojawienie się okna dialogowego z pytaniem o wylogowanie się z aplikacji
        {
            MessageDialog messageDialog = new MessageDialog(PassedData.askString);//Wyświetlenie treści komunikatu z pytaniem o wylogowanie się
            messageDialog.Commands.Add(new UICommand(PassedData.yesString, new UICommandInvokedHandler(CommandInvokedHandler)));//Dodanie przycisku z tekstem potwierdzający wylogowanie i obsługa po kliknięciu potwierdzającego wylogowanie
            messageDialog.Commands.Add(new UICommand(PassedData.noString));//Dodanie przycisku z tekstem anulujący wylogowanie się

            //Polecenie, które będzie wywołane jako potwierdzenie chęci wylogowania się z aplikacji 
            messageDialog.DefaultCommandIndex = 0;//Dla opcji obsługującej wylogowanie 

            //Polecenie, które będzie wywołane jako anulowanie chęci wylogowania się z aplikacji 
            messageDialog.CancelCommandIndex = 1;//Dla drugiej opcji anulującej wylogowanie

            //Wywołanie okna dialogowego
            await messageDialog.ShowAsync();
        }

        public void CommandInvokedHandler(IUICommand command)//Gdy użytkownik potwierdzi chęć wylogowania się z aplikacji
        {
            PassedData.LogOut = true;//Ustawienie flagi dla wylogowania użytkownika żeby wyświetlić komunikat o wylogowaniu się
            PassedData.isSelected = false;//Ustawienie domyślnej wartości flagi z wyborem motywu
            PassedData.chosenComboItem = null;////Ustawienie domyślnej wartości wybranego motywu
            PassedData.chosenTheme = "1";//Ustawienie domyślnej wartości motywu
            Frame.Navigate(typeof(MainPage));//Przeniesienie do strony logowania
        }
    }
}

