﻿using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.Globalization;
using System.Net.Http;
using System.Text.RegularExpressions;
using Windows.System;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;
using Windows.UI.Xaml.Navigation;

namespace Edug
{
    public sealed partial class QuestionPage : Page
    {
        public QuestionPage()
        {
            this.InitializeComponent();  
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            setLanguage();
            Functions.Function.getInfo();
            setAppBar();
            getMissionQuestions();
        }

        public string login = PassedData.agent_email, pswrd = PassedData.pswrd, passs = PassedData.loginPassword, system = PassedData.system, lang = PassedData.lang, game = PassedData.group, sum, sumOdp,sum1;
        //W login zapisany jest adres email agenta, pswrd - każdy z ważnych webserwisow wylicza crc zabezpieczone hasłem, crc wyliczone jako md5 od konkatenacji wszystkich argumentów poprzedzonych hasłem, tutaj hasłem jest wartość pswrd
        //passs - hasło agenta, system - system operacyjny, lang - język wyświetlanego tekstu dla agenta, game - identyfikator gry agenta 
        public string mission = PassedData.missionNumber, type = PassedData.missionType, headerFastMissionText, headerSpecMissionText, headerLaboMissionText;
        //W zmiennej "mission" jest zapisany identyfikator misji, w "type" jest kategoria misji, reszta to pomocnicze zmienne lokalne do nagłówków stron z poszczególnymi misjami
        public string emptyAnswerTextBox, emptyAnswer, urlContent;
        //Zmienne "emptyAnswerTextBox", "emptyAnswer" to pomocnicze zmienne lokalne do tekstów w metodzie setLanguage(), urlContent zachowuje adres url do pliku z metody getQuestion() dla ContentText_Click
        private async void ContentText_Click(object sender, RoutedEventArgs e)//Przenosi do strony z plikiem
        {
            await Launcher.LaunchUriAsync(new Uri(urlContent));
        }

        public void setLanguage()//Wyświetla tekst według języka agenta
        {
            switch (PassedData.lang)//Tekst na stronie jest wyświetlany w zależności od języka
            {
                case "pl"://W języku polskim
                    odpTextBox.PlaceholderText = "Wpisz odpowiedź";
                    sendButton.Content = "ODPOWIEDŹ";
                    headerFastMissionText = "MISJA BŁYSKAWICZNA";
                    headerSpecMissionText = "MISJA SPECJALNA";
                    headerLaboMissionText = "MISJA LABORATORYJNA";
                    BackButton.Label = "Powrót";
                    LogoutButton.Label = "Wyloguj";
                    nrTextBlock.Text = "Numer";
                    headTextBlock.Text = "Kryptonim";
                    FinishTimeTextBlock.Text = "Koniec";
                    ContentName.Text = "Treść";
                    emptyAnswerTextBox = "Wpisz odpowiedź zanim wyślesz";
                    emptyAnswer = "Nie zaznaczyłeś odpowiedzi";
                    break;
                case "en"://W języku angielskim
                    odpTextBox.PlaceholderText = "Write an answer";
                    sendButton.Content = "ANSWER";
                    headerFastMissionText = "FAST MISSION";
                    headerSpecMissionText = "SPECIAL MISSION";
                    headerLaboMissionText = "LAB MISSION";
                    BackButton.Label = "Back";
                    LogoutButton.Label = "Logout";
                    nrTextBlock.Text = "Number";
                    headTextBlock.Text = "Codename";
                    FinishTimeTextBlock.Text = "Finish";
                    ContentName.Text = "Content";
                    emptyAnswerTextBox = "Write answer before you send";
                    emptyAnswer = "You don't mark an answer";
                    break;
            }
        }

        public void setAppBar()//Wyświetla tekst i wartość przycisków na belce w dolnej części ekranu
        {
            AvatarAddAppBarButton.Label = PassedData.count_avatar + PassedData.countAvatarString;//Tekst i ilość zdobytych avatarów
            BitcoinAddAppBarButton.Label = PassedData.count_bitcoin + PassedData.countBitcoinString;//Tekst i ilość zdobytych bitcoinów
            ExacoinAddAppBarButton.Label = PassedData.count_exacoin + PassedData.countExacoinString;//Tekst i ilość zdobytych exacoinów
            PointsAddAppBarButton.Label = PassedData.count_point + PassedData.countPointString;//Tekst i ilość zdobytych punktów
        }

        public void getMissionQuestions()//Tworzenie adresów url do pobrania pytań według kategorii misji
        {
            String hash = MD5CryptoServiceProvider.GetMd5String(passs);//Skrót MD5 hasła agenta
            sum = pswrd + system + lang + game + mission + login + hash;
            //Zmienna "sum" to połączenie hasła dostępu, systemu operacyjnego, język wyświetlanego tekstu dla agenta, identyfikatora gry agenta, kategorii misji, loginu agenta oraz skrótu MD5 hasła agenta
            String crc = MD5CryptoServiceProvider.GetMd5String(sum);//Skrót MD5 zmiennej "sum"
            string url = null;
            switch (type)//Tworzenie adres url według kategorii misji
            {
                case "fast"://Dla misji błyskawicznej
                    headerMissionTextBlock.Text = headerFastMissionText;//Ustawienie nagłówka strony 
                    url = @"https://www.edug.pl/_webservices/mission_fast.php?sys=" + system + "&lang=" + lang + "&game=" + game + "&mission=" + mission + "&login=" + login + "&hash=" + hash + "&crc=" + crc;
                    //W zmiennej "url" jest zachowany adres url do pytania dla tej misji
                    getQuestions(url);//Uzyskanie treści pytania z webserwera
                    break;
                case "spec"://Dla misji specjalnej
                    headerMissionTextBlock.Text = headerSpecMissionText;//Ustawienie nagłówka strony 
                    url = @"https://www.edug.pl/_webservices/mission_spec.php?sys=" + system + "&lang=" + lang + "&game=" + game + "&mission=" + mission + "&login=" + login + "&hash=" + hash + "&crc=" + crc;
                    //W zmiennej "url" jest zachowany adres url do pytania dla tej misji
                    getQuestions(url);//Uzyskanie treści pytania z webserwera
                    break;
                case "labo"://Dla misji laboratoryjnej
                    headerMissionTextBlock.Text = headerLaboMissionText;//Ustawienie nagłówka strony 
                    url = @"https://www.edug.pl/_webservices/mission_labo.php?sys=" + system + "&lang=" + lang + "&game=" + game + "&mission=" + mission + "&login=" + login + "&hash=" + hash + "&crc=" + crc;
                    //W zmiennej "url" jest zachowany adres url do pytania dla tej misji
                    getQuestions(url);//Uzyskanie treści pytania z webserwera
                    break;
            }    
        }

        public async void getQuestions(string url)//Pobranie treści pytania
        {
            try
            {
                using (HttpClient client = new HttpClient())//Utworzenie klienta http w celu obsługi adresu url
                {
                    Uri uri = new Uri(url);//Inicjowanie nowej instacji klasy Uri z podanym adresem strony
                    client.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;//Sprawdzenie czy zaszła zmiana od ostatniego żądania do serwera od momentu wysłania zapytania
                    var Response = await client.GetAsync(uri);//Wysyła żądanie GET dla danego odnośnika URL
                    var statusCode = Response.StatusCode;//Rezultat i kod http
                    //Jeśli odpowiedź jest inna od Http 200
                    //wtedy metoda EnsureSuccessStatusCode wyrzuci wyjątek
                    Response.EnsureSuccessStatusCode();
                    string ResponseText1 = await Response.Content.ReadAsStringAsync();//Pobranie asynchronicznie odpowiedzi od webserwera
                    client.CancelPendingRequests();//Anulowanie wszelkich żądań do serwera
                    client.Dispose();//Zamknięcie klienta
                    getQuestion(ResponseText1);//Przetworzenie odpowiedzi od webserwera
                }
            }
            catch (Exception ex)//Przy pojawieniu się wyjątku, treść błędu jest wyświetlana w konsoli
            {
                Debug.WriteLine(ex);
            }
        }

        private void showLoading()//Przy ładowaniu obrazka pokazuje się napis "Loading..."
        {
            loadingView.Visibility = Visibility.Visible;//Widoczny napis ładowania
            imageSlot.Visibility = Visibility.Collapsed;//Niewidoczne miejsce dla obrazka
            errorView.Visibility = Visibility.Collapsed;//Niewidoczny napis do wyświetlania treści błędu
        }

        private void showError(string message)//Wyświetla treść błędu podczas ładowania
        {
            loadingView.Visibility = Visibility.Collapsed;//Niewidoczny napis ładowania
            imageSlot.Visibility = Visibility.Collapsed;//Niewidoczne miejsce dla obrazka
            errorView.Visibility = Visibility.Visible;//Widoczny napis do wyświetlania treści błędu
            errorView.Text = message;//Treść błędu
        }

        private void showImage()//Wyświetla obrazek
        {
            imageSlot.Visibility = Visibility.Visible;//Widoczny miejsce dla obrazka
            loadingView.Visibility = Visibility.Collapsed;//Niewidoczny napis ładowania
            errorView.Visibility = Visibility.Collapsed;//Niewidoczny napis do wyświetlania treści błędu
        }

        public void getQuestion(string data)//Wyświetla elementy na stronie w zależności od kategorii misji
        {
            //Podmiana części tekstu w odpowiedzi od webserwera, ponieważ funkcja DeserializeObject nie przetworzyłaby oryginalnej odpowiedzi
            string sourcestring;//zmienna lokalna
            String matchpattern = @"\""[1]\""";//Wzór tekstu do znalezienia dla wyrażenia regularnego
            String replacementpattern = @"""_1""";//Wzór tekstu do podmiany dla wyrażenia regularnego
            sourcestring = Regex.Replace(data, matchpattern, replacementpattern);
            //W treści odpowiedzi serwera (ResponseText) metoda Regex stara znaleźć tekst o podanym wzorze (matchpattern) i go podmienić na inny (replacementpattern)
            //-------------------
            matchpattern = @"\""[2]\""";
            replacementpattern = @"""_2""";
            sourcestring = Regex.Replace(sourcestring, matchpattern, replacementpattern);
            //-------------------
            matchpattern = @"\""[3]\""";
            replacementpattern = @"""_3""";
            sourcestring = Regex.Replace(sourcestring, matchpattern, replacementpattern);
            //-------------------
            matchpattern = @"\""[4]\""";
            replacementpattern = @"""_4""";
            sourcestring = Regex.Replace(sourcestring, matchpattern, replacementpattern);
            //------------------------------------------------
            matchpattern = @"\<\w\w.\\\/\>";
            replacementpattern = @"\n";
            sourcestring = Regex.Replace(sourcestring, matchpattern, replacementpattern);

            Classes.RootObject obj = JsonConvert.DeserializeObject<Classes.RootObject>(sourcestring);//Przetworzenie pliku json do typu.NET
            string result = obj.mission_fast.result.ToString();//rezultat czy dane były poprawne
            string comment = obj.mission_fast.comment;//Gdy dane były niepoprawne, w tej zmiennej jest zapisany treść błędu
            try
            {
                if (result == "True")//Gdy dane były poprawne
                {
                    CommentGrid.Visibility = Visibility.Collapsed;//Obszar, gdzie treść błędu byłaby wyświetlana, jest niewidoczny
                    string codename = obj.mission_fast.codename.ToString();//Kryptonim gry
                    string mission_start = obj.mission_fast.mission_start;//Godzina rozpoczęcia misji
                    string mission_text = obj.mission_fast.mission_text;//Treść pytania dla misji błyskawicznej
                    string finish_time = obj.mission_fast.finish_time;//Godzina rozpoczęcia misji
                    string mission_file = obj.mission_fast.mission_file;//Ścieżka do plik dla misji laboratoryjnej
                    object picture = obj.mission_fast.picture;//Ścieżka do obrazka
                    string question1 = obj.mission_fast.question_1;//Treść pierwszego pytania dla misji specjalnej
                    string question2 = obj.mission_fast.question_2;//Treść drugiego pytania dla misji specjalnej
                    string question3 = obj.mission_fast.question_3;//Treść trzeciego pytania dla misji specjalnej
                    string question4 = obj.mission_fast.question_4;//Treść czwartego pytania dla misji specjalnej
                    //w C# 6 można ustawić że zmienna może przyjmować różne wartości, w tym też null za pomocą znaku "?"
                    //np. var title = person.Title?.ToUpper();
                    //Odpowiedzi dla pierwszego pytania z misji specjalnej lub błyskawicznej
                    string answer11 = obj.mission_fast.answers_1?._1;//Treść pierwszej odpowiedzi 
                    string answer12 = obj.mission_fast.answers_1?._2;//Treść drugiej odpowiedzi 
                    string answer13 = obj.mission_fast.answers_1?._3;//Treść trzeciej odpowiedzi 
                    string answer14 = obj.mission_fast.answers_1?._4;//Treść czwartej odpowiedzi
                    //Odpowiedzi dla drugiego pytania z misji specjalnej
                    string answer21 = obj.mission_fast.answers_2?._1;
                    string answer22 = obj.mission_fast.answers_2?._2;
                    string answer23 = obj.mission_fast.answers_2?._3;
                    string answer24 = obj.mission_fast.answers_2?._4;
                    //Odpowiedzi dla trzeciego pytania z misji specjalnej
                    string answer31 = obj.mission_fast.answers_3?._1;
                    string answer32 = obj.mission_fast.answers_3?._2;
                    string answer33 = obj.mission_fast.answers_3?._3;
                    string answer34 = obj.mission_fast.answers_3?._4;
                    //Odpowiedzi dla czwartego pytania z misji specjalnej
                    string answer41 = obj.mission_fast.answers_4?._1;
                    string answer42 = obj.mission_fast.answers_4?._2;
                    string answer43 = obj.mission_fast.answers_4?._3;
                    string answer44 = obj.mission_fast.answers_4?._4;

                    numberTextBlock.Text = mission;//Wyświetla numer misji
                    headerTextBlock.Text = codename;//Wyświetla kryptonim misji
                    if (mission_start == null)//Gdy nie ma podanej godziny rozpoczęcia misji (dla misji laboratoryjnej)
                    {
                        StartTime.Visibility = Visibility.Collapsed;//Tekst z godziną nie jest wyświetlany
                    }
                    else
                    {
                        StartTime.Text = mission_start;//Wyświetla godzinę rozpoczęcia misji
                    }
                    if (finish_time == null)//Gdy nie ma podanej godziny rozpoczęcia misji (dla misji laboratoryjnej)
                    {
                        FinishTime.Visibility = Visibility.Collapsed;
                    }
                    else
                    {
                        FinishTime.Text = finish_time;//Wyświetla godzinę końca misji
                    }

                    if (type == "spec")
                    {
                        answerTextBox.Visibility = Visibility.Collapsed;
                        ContentName.Visibility = Visibility.Collapsed;
                        ContentText.Visibility = Visibility.Collapsed;
                        //Dla pytania numer 1
                        if (question1 == null)
                        {
                            Question1Grid.Visibility = Visibility.Collapsed;
                        }
                        else
                        {
                            Question1TextBlock.Text = question1;
                            if (answer11 == null)
                            {
                                Answer11.Visibility = Visibility.Collapsed;
                                CheckBox11.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer11.Text = answer11;
                            }
                            if (answer12 == null)
                            {
                                Answer12.Visibility = Visibility.Collapsed;
                                CheckBox12.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer12.Text = answer12;
                            }
                            if (answer13 == null)
                            {
                                Answer13.Visibility = Visibility.Collapsed;
                                CheckBox13.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer13.Text = answer13;
                            }
                            if (answer14 == null)
                            {
                                Answer14.Visibility = Visibility.Collapsed;
                                CheckBox14.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer14.Text = answer14;
                            }
                        }
                        //Dla pytania numer 2
                        if (question2 == null)
                        {
                            Question2Grid.Visibility = Visibility.Collapsed;
                        }
                        else
                        {
                            Question2TextBlock.Text = question2;
                            if (answer21 == null)
                            {
                                Answer21.Visibility = Visibility.Collapsed;
                                CheckBox21.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer21.Text = answer21;
                            }
                            if (answer22 == null)
                            {
                                Answer22.Visibility = Visibility.Collapsed;
                                CheckBox22.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer22.Text = answer22;
                            }
                            if (answer23 == null)
                            {
                                Answer23.Visibility = Visibility.Collapsed;
                                CheckBox23.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer23.Text = answer23;
                            }
                            if (answer24 == null)
                            {
                                Answer24.Visibility = Visibility.Collapsed;
                                CheckBox24.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer24.Text = answer24;
                            }
                        }
                        //Dla pytania numer 3
                        if (question3 == null)
                        {
                            Question3Grid.Visibility = Visibility.Collapsed;
                        }
                        else
                        {
                            Question3TextBlock.Text = question3;
                            if (answer31 == null)
                            {
                                Answer31.Visibility = Visibility.Collapsed;
                                CheckBox31.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer31.Text = answer31;
                            }
                            if (answer32 == null)
                            {
                                Answer32.Visibility = Visibility.Collapsed;
                                CheckBox32.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer32.Text = answer32;
                            }
                            if (answer33 == null)
                            {
                                Answer33.Visibility = Visibility.Collapsed;
                                CheckBox33.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer33.Text = answer33;
                            }
                            if (answer34 == null)
                            {
                                Answer34.Visibility = Visibility.Collapsed;
                                CheckBox34.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer34.Text = answer34;
                            }
                        }
                        //Dla pytania numer 4
                        if (question4 == null)
                        {
                            Question4Grid.Visibility = Visibility.Collapsed;
                        }
                        else
                        {
                            Question4TextBlock.Text = question4;
                            if (answer41 == null)
                            {
                                Answer41.Visibility = Visibility.Collapsed;
                                CheckBox41.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer41.Text = answer41;
                            }
                            if (answer42 == null)
                            {
                                Answer42.Visibility = Visibility.Collapsed;
                                CheckBox42.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer42.Text = answer42;
                            }
                            if (answer43 == null)
                            {
                                Answer43.Visibility = Visibility.Collapsed;
                                CheckBox43.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer43.Text = answer43;
                            }
                            if (answer44 == null)
                            {
                                Answer44.Visibility = Visibility.Collapsed;
                                CheckBox44.Visibility = Visibility.Collapsed;
                            }
                            else
                            {
                                Answer44.Text = answer44;
                            }
                        }
                    }
                    else if (type == "labo")//widocznosc elementow gdy wyswietlana misja to lab
                    {
                        ContentName.Visibility = Visibility.Visible;
                        ContentText.Visibility = Visibility.Visible;
                        urlContent = mission_file;
                        int index = mission_file.LastIndexOf("/");
                        mission_file = mission_file.Substring(index+1);
                        ContentText.Content = mission_file;
                        Send.Visibility = Visibility.Collapsed;
                        Question1Grid.Visibility = Visibility.Collapsed;
                        Question2Grid.Visibility = Visibility.Collapsed;
                        Question3Grid.Visibility = Visibility.Collapsed;
                        Question4Grid.Visibility = Visibility.Collapsed;
                    }
                    else//błyskawiczna misja
                    {
                        ContentName.Visibility = Visibility.Collapsed;
                        ContentText.Visibility = Visibility.Collapsed;
                        Question2Grid.Visibility = Visibility.Collapsed;
                        Question3Grid.Visibility = Visibility.Collapsed;
                        Question4Grid.Visibility = Visibility.Collapsed;
                        CheckBox11.Visibility = Visibility.Collapsed;
                        Answer11.Visibility = Visibility.Collapsed;
                        CheckBox12.Visibility = Visibility.Collapsed;
                        Answer12.Visibility = Visibility.Collapsed;
                        CheckBox13.Visibility = Visibility.Collapsed;
                        Answer13.Visibility = Visibility.Collapsed;
                        CheckBox14.Visibility = Visibility.Collapsed;
                        Answer14.Visibility = Visibility.Collapsed;

                        if (picture == null || picture.Equals(""))
                        {
                            ImageGrid.Visibility = Visibility.Collapsed;
                        }
                        else
                        {
                            var bitmap = new BitmapImage(new Uri(picture.ToString()));
                            bitmap.ImageFailed += (s, e) => this.showError("Error while loading the image.");
                            bitmap.ImageOpened += (s, e) => this.showImage();
                            showLoading();
                            imageSlot.Source = bitmap;
                        }
                        Question1TextBlock.Text = mission_text;
                    }
                }
                else if (result == "False")
                {
                    commentTextBlock.Text = comment;
                    ContentGrid.Visibility = Visibility.Collapsed;      
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
        }

        private void sendButton_Click(object sender, RoutedEventArgs e)
        {
            string mission = PassedData.missionNumber;
            string type = PassedData.missionType;
            string answer11 = null, answer12 = null, answer13 = null, answer14 = null;//odpowiedzi dla pytania nr 1
            string answer21 = null, answer22 = null, answer23 = null, answer24 = null;//odpowiedzi dla pytania nr 2 
            string answer31 = null, answer32 = null, answer33 = null, answer34 = null;//odpowiedzi dla pytania nr 3
            string answer41 = null, answer42 = null, answer43 = null, answer44 = null;//odpowiedzi dla pytania nr 4
            string answer1 = null, answer2 = null, answer3 = null, answer4 = null;
            string url = null;
            String crcOdp = null;
            //------------------------------------------
            String hash = MD5CryptoServiceProvider.GetMd5String(passs);
            sum = pswrd + system + lang + game + mission + login + hash;
            String crc = MD5CryptoServiceProvider.GetMd5String(sum);
            // BSIBSIwpplamw145tesmatgrauman@gmail.com5d61b33868329ec1d305daba428e2feb
            //-----------------------------
            if (CheckBox11.IsChecked == true)
            {
                answer11 += "1";
            }
            if (CheckBox12.IsChecked == true)
            {
                answer12 += "2";
            }
            if (CheckBox13.IsChecked == true)
            {
                answer13 += "3";
            }
            if (CheckBox14.IsChecked == true)
            {
                answer14 += "4";
            }
            //------------------------------------------------
            if (CheckBox21.IsChecked == true)
            {
                answer21 += "1";
            }
            if (CheckBox22.IsChecked == true)
            {
                answer22 += "2";
            }
            if (CheckBox23.IsChecked == true)
            {
                answer23 += "3";
            }
            if (CheckBox24.IsChecked == true)
            {
                answer24 += "4";
            }
            //------------------------------------------------
            if (CheckBox31.IsChecked == true)
            {
                answer31 += "1";
            }
            if (CheckBox32.IsChecked == true)
            {
                answer32 += "2";
            }
            if (CheckBox33.IsChecked == true)
            {
                answer33 += "3";
            }
            if (CheckBox34.IsChecked == true)
            {
                answer34 += "4";
            }
            //------------------------------------------------
            if (CheckBox41.IsChecked == true)
            {
                answer41 += "1";
            }
            if (CheckBox42.IsChecked == true)
            {
                answer42 += "2";
            }
            if (CheckBox43.IsChecked == true)
            {
                answer43 += "3";
            }
            if (CheckBox44.IsChecked == true)
            {
                answer44 += "4";
            }
            switch (type)
            {
                case "fast":
                    if (String.IsNullOrEmpty(odpTextBox.Text))
                    {
                        Functions.Function.showMessage(emptyAnswerTextBox);
                    }
                    else
                    {
                        sumOdp = pswrd + system + lang + game + mission + odpTextBox.Text + login + hash;
                        crcOdp = MD5CryptoServiceProvider.GetMd5String(sumOdp);
                        url = @"https://www.edug.pl/_webservices/mission_fast.php?sys=" + system + "&lang=" + lang + "&game=" + game + "&mission=" + mission + "&answer=" + odpTextBox.Text + "&login=" + login + "&hash=" + hash + "&crc=" + crcOdp;
                        sendAnswer(url);
                        Frame.Navigate(typeof(MissionPage));
                    }
                    break;
                case "spec":
                    answer1 = answer11 + answer12 + answer13 + answer14;
                    answer2 = answer21 + answer22 + answer23 + answer24;
                    answer3 = answer31 + answer32 + answer33 + answer34;
                    answer4 = answer41 + answer42 + answer43 + answer44;
                    if (String.IsNullOrEmpty(answer1) || String.IsNullOrEmpty(answer2) || String.IsNullOrEmpty(answer3) || String.IsNullOrEmpty(answer4))
                    {
                        Functions.Function.showMessage(emptyAnswer);          
                    }
                    else
                    {
                        sumOdp = pswrd + system + lang + game + mission + answer1 + answer2 + answer3 + answer4 + login + hash;
                        crcOdp = MD5CryptoServiceProvider.GetMd5String(sumOdp);
                        url = @"https://www.edug.pl/_webservices/mission_spec.php?sys=" + system + "&lang=" + lang + "&game=" + game + "&mission=" + mission + "&answer1=" + answer1 + "&answer2=" + answer2 + "&answer3=" + answer3 + "&answer4=" + answer4 + "&login=" + login + "&hash=" + hash + "&crc=" + crcOdp;
                        sendAnswer(url);
                        Frame.Navigate(typeof(MissionPage));
                    }
                    break;
                default:
                    break;
            }
        }

        public async void sendAnswer(string url)
        {//do wyslania odp na serwer
            try
            {
                //Create Client 
                using (HttpClient client = new HttpClient())
                {
                    //Define URL. Replace current URL with your URL
                    //Current URL is not a valid one
                    Uri uri = new Uri(url);
                    client.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;
                    //Call. Get response by Async
                    var Response = await client.GetAsync(uri);
                    //Result & Code
                    var statusCode = Response.StatusCode;
                    //If Response is not Http 200 
                    //then EnsureSuccessStatusCode will throw an exception
                    Response.EnsureSuccessStatusCode();
                    var ResponseText = await Response.Content.ReadAsStringAsync();
                    Classes.RootObject obj = JsonConvert.DeserializeObject<Classes.RootObject>(ResponseText);
                    string mess = obj.mission_fast.comment.ToString();
                    Functions.Function.showMessage(mess);
                    client.CancelPendingRequests();
                    client.Dispose();
                    Frame.Navigate(typeof(MissionPage));
                }       
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex);
            }
        }      

        private void backButton_Click(object sender, RoutedEventArgs e)
        {
            Frame.Navigate(typeof(MissionPage));
        }

        private async void logoutButton_Click(object sender, RoutedEventArgs e)
        {

            MessageDialog messageDialog = new MessageDialog(PassedData.askString);
            messageDialog.Commands.Add(new UICommand(PassedData.yesString, new UICommandInvokedHandler(CommandInvokedHandler)));
            messageDialog.Commands.Add(new UICommand(PassedData.noString));

            // Set the command that will be invoked by default
            messageDialog.DefaultCommandIndex = 0;

            // Set the command to be invoked when escape is pressed
            messageDialog.CancelCommandIndex = 1;

            // Show the message dialog
            await messageDialog.ShowAsync();
        }

        public void CommandInvokedHandler(IUICommand command)
        {
            PassedData.LogOut = true;
            PassedData.isSelected = false;
            PassedData.chosenComboItem = null;
            PassedData.chosenTheme = "1";
            Frame.Navigate(typeof(MainPage));
        }
    }
}

