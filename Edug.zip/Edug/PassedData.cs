﻿using System.Collections.Generic;

namespace Edug
{
    public class PassedData
    {
        public static string agent_number { get; set; }//Identyfikator agenta
        public static string agent_name { get; set; }//Imię i nazwisko agenta
        public static string agent_email { get; set; }//Adres email agenta
        public static string count_bitcoin { get; set; }//Liczba zdobytych bitcoinów 
        public static string count_avatar { get; set; }//Liczba zdobytych avatarów
        public static string count_exacoin { get; set; }//Liczba zdobytych exacoinów
        public static string count_mission { get; set; }//Liczba wszystkich aktywnych misji 
        public static string count_point { get; set; }//Liczba zdobytych punktów 
        public static string count_badges_style { get; set; }//Liczba motywów 
        public static string lang="pl";//Język agenta, standartowo jest ustawiony na polski
        public static string group { get; set; }//Identyfikator gry agenta
        public static string missionNumber { get; set; }//Numer zapisanej misji
        public static string missionType { get; set; }//Kategoria zapisanej misji
        public static string pswrd="grauman";//Hasło dostępu do webserwera
        public static string system="wp";//System operacyjny gdzie uruchomiona jest aplikacja (Windows Phone)
        public static string chosenComboItem { get; set; }//Wartość wybranego elementu z comboBoxa od motywów
        public static string chosenTheme="1";//Dla motywu standardowo jest ustawiona wartość "1"
        public static bool isSelected = false;//Gdy wybrano motyw z comboBoxa
        public static bool LogOut = false;//Flaga informująca czy nalezy wyświetlić komunikat o wylogowaniu się, dla false nie wyświetla, dla true wyświetla
        public static string login { get; set; }//Login agenta
        public static string loginPassword { get; set; }//Hasło agenta
        public static string askString;//Treść pytania w komunikacie przy próbie wylogowania się
        public static string yesString;//Treść zdania w przycisku, do którego zapisana jest metoda do potwierdzenia chęci wylogowania się
        public static string noString;//Treść zdania w przycisku, do którego zapisana jest metoda do anulowania chęci wylogowania się
        public static string countAvatarString, countBitcoinString, countExacoinString, countPointString;//Teksty przy okrągłych ikonach na dolnym wysuwanym pasku
        public static string startString { get; set; }//Zapisana godzina rozpoczęcia misji
        public static string finishString { get; set; }//Zapisana godzina zakończenia misji
        public static string url { get; set; }//Zapisany adres url
        public static string urlForQuestion { get; set; }//Zapisany adres url do pytania
        public static Dictionary<string, string> slownik = new Dictionary<string, string>();//Do zapisania w parach klucz-wartość
    }
}
