﻿using Newtonsoft.Json;
using System;
using System.Net.Http;
using Windows.Storage;
using Windows.UI.Popups;
using Windows.UI.Text;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace Edug
{
    public sealed partial class MenuPage : Page
    {
        public MenuPage()
        {
            this.InitializeComponent();
        }
                     
        protected override void OnNavigatedTo(NavigationEventArgs e)//Wywowyłana gdy strona stanie się aktywna
        {
            setLanguage();
            getAccountDetails();
        }

        public void CommandInvokedHandler(IUICommand command)//Wywoływana gdy użytkownik potwierdzi chęć wylogowania się z aplikacji
        {
            PassedData.LogOut = true;//Ustawienie flagi dla wylogowania użytkownika żeby wyświetlić komunikat o wylogowaniu się
            Frame.Navigate(typeof(MainPage));//Przeniesienie do strony logowania
        }

        private async void logoutButton_Click(object sender, RoutedEventArgs e)//Obsługuje naciśnięcie przycisku do wylogowania się z aplikacji
        {
            MessageDialog messageDialog = new MessageDialog(PassedData.askString);//Wyświetlenie treści komunikatu z pytaniem o wylogowanie się
            messageDialog.Commands.Add(new UICommand(PassedData.yesString, new UICommandInvokedHandler(CommandInvokedHandler)));//Obsługa przy kliknięciu potwierdzającego wylogowanie
            messageDialog.Commands.Add(new UICommand(PassedData.noString));//Obsługa przy kliknięciu anulującego wylogowanie

            //Polecenie, które będzie wywołane jako potwierdzenie chęci wylogowania się z aplikacji 
            messageDialog.DefaultCommandIndex = 0;//0 dla opcji z CommandInvokedHandler

            //Polecenie, które będzie wywołane jako anulowanie chęci wylogowania się z aplikacji 
            messageDialog.CancelCommandIndex = 1;//1 dla drugiej opcji bez CommandInvokedHandler

            //Pokazanie okna z zapytaniem o chęć wylogowania się
            await messageDialog.ShowAsync();
        }

        private void missionButton_Click(object sender, RoutedEventArgs e)//Przenosi do strony z misjami
        {
            Frame.Navigate(typeof(MissionPage));
        }

        private void reachButton_Click(object sender, RoutedEventArgs e)//Przenosi do strony z osiągnięciami agenta
        {
            Frame.Navigate(typeof(ResultPage));
        }

        private void rankButton_Click(object sender, RoutedEventArgs e)//Przenosi do strony z rankigiem
        {
            Frame.Navigate(typeof(RankPage));
        }

        private void presenceButton_Click(object sender, RoutedEventArgs e)//Przenosi do strony z obecnościami agenta
        {
            Frame.Navigate(typeof(PresencePage));
        }

        private void fileButton_Click(object sender, RoutedEventArgs e)//Przenosi do strony z plikami do pobrania
        {
            Frame.Navigate(typeof(FilePage));
        }

        private void decorationButton_Click(object sender, RoutedEventArgs e)//Przenosi do strony z odznaczeniami
        {
            Frame.Navigate(typeof(DecorationsPage));
        }

        public string placeHolderString, motywString;//Pomocnicze stringi dla placeholdera i motywu

        public void setLanguage()//Ustawia tekst wyświetlany na ekranie według języka agenta
        {
            switch (PassedData.lang)
            {
                case "pl"://gdy język agenta to polski
                    AgentNumberTextBlock.Text = "Numer: ";
                    AgentNameTextBlock.Text = "Agent: ";
                    AgentGroupTextBlock.Text = "Grupa: ";
                    AgentMissionTextBlock.Text = "Misje: ";
                    AgentAvatarTextBlock.Text = "Awatary: ";
                    AgentBitcoinsTextBlock.Text = "Bitcoiny [฿]: ";
                    AgentExacoinsTextBlock.Text = "Exacoiny [$]: ";
                    AgentPointsTextBlock.Text = "Punkty: ";
                    border1TextBlock.Text = "Niezbędnik";
                    missionButton.Content = "Misje";
                    reachButton.Content = "Osiągnięcia";
                    rankButton.Content = "Rankingi";
                    presenceButton.Content = "Obecności";
                    decorationButton.Content = "Odznaczenia";
                    motywString = "Motyw ";
                    PassedData.askString = "Czy chcesz wyjść z programu?";
                    PassedData.yesString = "Tak";
                    PassedData.noString = "Nie";
                    placeHolderString = "Wybierz motyw";
                    PassedData.countAvatarString = " avatarów";
                    PassedData.countBitcoinString = " bitcoinów";
                    PassedData.countExacoinString = " exacoinów";
                    PassedData.countPointString = " punktów";
                    LogoutButton.Label = "Wyloguj";
                    themeTextBlock.Text = "Wybierz motyw";
                    break;
                case "en"://angielski
                    AgentNumberTextBlock.Text = "Number: ";
                    AgentNameTextBlock.Text = "Agent: ";
                    AgentGroupTextBlock.Text = "Group: ";
                    AgentMissionTextBlock.Text = "Missions: ";
                    AgentAvatarTextBlock.Text = "Avatars";
                    AgentBitcoinsTextBlock.Text = "Bitcoins [฿]: ";
                    AgentExacoinsTextBlock.Text = "Exacoins [$]: ";
                    AgentPointsTextBlock.Text = "Points : ";
                    border1TextBlock.Text = "Essentials";
                    missionButton.Content = "Missions : ";
                    reachButton.Content = "Achievements";
                    rankButton.Content = "Rankings";
                    presenceButton.Content = "Presences";
                    decorationButton.Content = "Honors";
                    motywString = "Theme ";
                    PassedData.askString = "Do you want to exit the program?";
                    PassedData.yesString = "Yes";
                    PassedData.noString = "No";
                    placeHolderString = "Choose a theme";
                    PassedData.countAvatarString = " avatars";
                    PassedData.countBitcoinString = " bitcoins";
                    PassedData.countExacoinString = " exacoins";
                    PassedData.countPointString = " points";
                    LogoutButton.Label = "Log out";
                    themeTextBlock.Text = "Choose theme";
                    break;
            }
        }

        private void comboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)//Obłsuga wyboru motywu
        {
            string choose = ((ComboBoxItem)comboBox.SelectedItem).Content.ToString();//Zapamiętany jest wybrany motyw
            PassedData.chosenComboItem = choose;//Zapisany numer motywu
            choose = choose.Substring(choose.Length-1);//Z nazwy motywu zdobywamy numer motywu
            PassedData.chosenTheme = choose;//Zapisany numer motywu
            PassedData.isSelected = true;//Zapisany że wybrany jest motyw
        }

        public async void getAccountDetails()//Metoda do pobrania danych 
        {
            //wartości stringów są pobierane z klasy PassedData która zachowuje potrzebne informacje
            string login = PassedData.login, pswrd = PassedData.pswrd, passs = PassedData.loginPassword, system = PassedData.system, lang = PassedData.lang, game = PassedData.group, sum;

            String hash = MD5CryptoServiceProvider.GetMd5String(passs);//skrót MD5 hasła użytkownika
            sum = pswrd + system + lang + game + login + hash;//suma ciągu znaków hasła dostępu,systemu, języka, grupy, loginu oraz hasła użytkownika
            String crc = MD5CryptoServiceProvider.GetMd5String(sum);//skrót MD5 sumy ciągu znaków
            //url to odnośnik do pobrania informacji o agencie
            string url = @"https://www.edug.pl/_webservices/user_account.php?sys=" + system + "&lang=" + lang + "&game=" + game + "&login=" + login + "&hash=" + hash + "&crc=" + crc;
            PassedData.url = url;
            using (HttpClient httpClient = new HttpClient())//Utworzenie klienta http w celu obsługi url
            {
                Uri uri = new Uri(url);//Inicjowanie nowej instacji klasy Uri z podanym odnośnikiem
                httpClient.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;//Sprawdzenie czy zaszła zmiana od ostatniego żądania do serwera od momentu wysłania zapytania
                var Response = await httpClient.GetAsync(uri);//Wysyła żądanie GET dla danego odnosnika URL
                Response.EnsureSuccessStatusCode();
                //Jeśli odpowiedź jest inna od Http 200
                //wtedy metoda EnsureSuccessStatusCode wyrzuci wyjątek
                var json = await Response.Content.ReadAsStringAsync();//pobranie asynchronicznie odpowiedzi od serwera
                httpClient.CancelPendingRequests();//Anulowanie wszelkich żądan do serwera
                httpClient.Dispose();//Zamknięcie klienta
                getDetails(json);//Obsługa pliku json by uzyskać informacje o agencie
                details();//Metoda do wyświetlenia informacji
            }
        }

        public void getDetails(string data)//Pobranie danych o agencie
        {
            Classes.RootObject obj = JsonConvert.DeserializeObject<Classes.RootObject>(data);//konwersja odpowiedzi od serwera
            string ResponseText = obj.user_account.result.ToString();//odpowiedź serwera przy pobieraniu danych

            if (ResponseText.Equals("True"))//gdy dany agent istnieje, przekazywane są dane
            {
                PassedData.agent_number = obj.user_account.agent_number.ToString();//numer agenta
                PassedData.agent_name = obj.user_account.agent_name.ToString();//nazwa agenta
                PassedData.agent_email = obj.user_account.agent_email.ToString();//email agenta
                PassedData.count_badges_style = obj.user_account.count_badges_style.ToString();//liczba motywów
                PassedData.lang = obj.user_account.lang.ToString();//język agenta
                PassedData.count_bitcoin = obj.user_account.count_bitcoin.ToString();//liczba bitcoinów
                PassedData.count_avatar = obj.user_account.count_avatar.ToString();//liczba avatarów
                PassedData.count_exacoin = obj.user_account.count_exacoin.ToString();//liczba exacoinów
                PassedData.count_mission = obj.user_account.count_mission.ToString();//liczba misji
                PassedData.count_point = obj.user_account.count_point.ToString();//liczba zdobytych puntktów
            }
            else
            {
                Functions.Function.showMessage("Błąd przy pobieraniu danych.");//komunikat gdy przy pobieraniu informacji pojawi się komuniakt "false"
            }
        }

        public void details()//Pobranie danych i ich wyświetlenie na ekranie
        {
            AgentNameValueTextBlock.Text = PassedData.agent_name;//nazwa agenta
            AgentGroupValueTextBlock.Text = PassedData.group;//grupa agenta
            AgentNumberValueTextBlock.Text = PassedData.agent_number;//numer agenta
            AgentMissionValueTextBlock.Text = PassedData.count_mission;//liczba misji
            AgentAvatarValueTextBlock.Text = PassedData.count_avatar;//liczba avatarów
            AgentBitcoinsValueTextBlock.Text = PassedData.count_bitcoin;//liczba bitcoinów
            AgentExacoinsValueTextBlock.Text = PassedData.count_exacoin;//liczba exacoinów
            AgentPointsValueTextBlock.Text = PassedData.count_point;//liczba zdobytych puntktów

            //sprawdzam liczbę oraz język w celu poprawnego wyświetlenia dla danych punktów
            if (Int32.Parse(PassedData.count_avatar)== 1 && PassedData.lang=="pl")//domyślnie wyświetla "avatarów" dla języka polskiego od pięciu avatarów i powyżej
            {
                PassedData.countAvatarString = PassedData.countAvatarString.Remove(PassedData.countAvatarString.Length - 2);//wyświetla słowo "avatar" dla jednego avatara
            }else if (Int32.Parse(PassedData.count_avatar) >= 2 && Int32.Parse(PassedData.count_avatar) <= 4 && PassedData.lang == "pl")
            {
                PassedData.countAvatarString = PassedData.countAvatarString.Remove(PassedData.countAvatarString.Length - 2);//wyświetla słowo "avatary" od dwóch do czterech avatarów
                PassedData.countAvatarString += "y";
            }
            else if (Int32.Parse(PassedData.count_avatar) == 1 && PassedData.lang == "en")// domyślnie wyświetla "avatars" dla języka angielskiego od dwóch avatarów i powyżej
            {
                PassedData.countAvatarString = PassedData.countAvatarString.Remove(PassedData.countAvatarString.Length - 1);//wyświetla słowo "avatar" dla jednego avatara w języku angielskim
            }

            if (Int32.Parse(PassedData.count_bitcoin) == 1 && PassedData.lang == "pl")//domyślnie wyświetla "bitcoinów" dla języka polskiego od dwóch bitcoinów i powyżej
            {
                PassedData.countBitcoinString = PassedData.countBitcoinString.Remove(PassedData.countBitcoinString.Length - 2);//wyświetla słowo "bitcoin" dla jednego bitcoina
            }
            else if (Int32.Parse(PassedData.count_bitcoin) >= 2 && Int32.Parse(PassedData.count_bitcoin) <= 4 && PassedData.lang == "pl")
            {
                PassedData.countBitcoinString = PassedData.countBitcoinString.Remove(PassedData.countBitcoinString.Length - 2);//wyświetla słowo "bitcoiny" od dwóch do czterech bitcoinów
                PassedData.countBitcoinString += "y";
            }
            else if (Int32.Parse(PassedData.count_bitcoin) == 1 && PassedData.lang == "en")//domyślnie wyświetla "bitcoins" dla języka angielskiego od dwóch bitcoinów i powyżej
            {
                PassedData.countBitcoinString = PassedData.countBitcoinString.Remove(PassedData.countBitcoinString.Length - 1);//wyświetla słowo "bitcoin" dla jednego bitcoina w języku angielskim
            }

            if (Int32.Parse(PassedData.count_exacoin)== 1 && PassedData.lang == "pl")//domyślnie wyświetla "exacoinów" dla języka polskiego od dwóch exacoinów i powyżej
            {
                PassedData.countExacoinString = PassedData.countExacoinString.Remove(PassedData.countExacoinString.Length - 2);//wyświetla słowo "exacoin"
            }
            else if (Int32.Parse(PassedData.count_exacoin) >= 2 && Int32.Parse(PassedData.count_exacoin) <= 4 && PassedData.lang == "pl")
            {
                PassedData.countExacoinString = PassedData.countExacoinString.Remove(PassedData.countExacoinString.Length - 2);//wyświetla słowo "exacoiny" od dwóch do czterech exacoinów
                PassedData.countExacoinString += "y";
            }
            else if (Int32.Parse(PassedData.count_exacoin) == 1 && PassedData.lang == "en") //domyślnie wyświetla "exacoins" dla języka angielskiego od dwóch bitcoinów i powyżej
            {
                PassedData.countExacoinString = PassedData.countExacoinString.Remove(PassedData.countExacoinString.Length - 1);//wyświetla słowo "exacoin" dla jednego exacoina w języku angielskim
            }

            if (Int32.Parse(PassedData.count_point)== 1 && PassedData.lang == "pl")//domyślnie wyświetla "punktów" dla języka polskiego od pięciu punktów i powyżej
            {
                PassedData.countPointString = PassedData.countPointString.Remove(PassedData.countPointString.Length - 2);//wyświetla słowo "punkt" dla jednego punktu
            }
            else if (Int32.Parse(PassedData.count_point) >= 2 && Int32.Parse(PassedData.count_point) <= 4 && PassedData.lang == "pl")
            {
                PassedData.countPointString = PassedData.countPointString.Remove(PassedData.countPointString.Length - 2);//wyświetla słowo "punkty" od dwóch do czterech exacoinów
                PassedData.countPointString += "y";
            }
            else if (Int32.Parse(PassedData.count_point) == 1 && PassedData.lang == "en")//domyślnie wyświetla "points" dla języka angielskiego od dwóch punktów i powyżej
            {
                PassedData.countPointString = PassedData.countPointString.Remove(PassedData.countPointString.Length - 1);//wyświetla słowo "point" dla jednego punktu w języku angielskim
            }
            //wyświetlanie wyników w AppBarze (pasek na dole ekranu z czterema ikonami)
            AvatarAddAppBarButton.Label = PassedData.count_avatar + PassedData.countAvatarString;//dla avatarów
            BitcoinAddAppBarButton.Label = PassedData.count_bitcoin + PassedData.countBitcoinString;//dla bitcoinów
            ExacoinAddAppBarButton.Label = PassedData.count_exacoin + PassedData.countExacoinString;//dla exacoinów
            PointsAddAppBarButton.Label = PassedData.count_point + PassedData.countPointString;//dla punktów

            if (PassedData.isSelected == false)//gdy użytkownik nie wybierze to wyświetlany jest tekst z podpowiedzią o wyborze motywy
            {
                comboBox.PlaceholderText = placeHolderString;//treść podpowiedzi
            }
            else
            {
                comboBox.PlaceholderText = PassedData.chosenComboItem;//po wyborze motyw jest zapamiętany
            }

            if(comboBox.Items.Count <= 0)
            {
                int licznik = int.Parse(PassedData.count_badges_style);//pobierana jest liczba motywów i parsowana z stringa na int
                for (int i = 1; i <= licznik; i++)
                {
                    comboBox.Items.Add(new ComboBoxItem { Content = motywString + i });//do przycisku z wyborem motywu dodawane są opcje  
                }
            }
        }
    }
}

