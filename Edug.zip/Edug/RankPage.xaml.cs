﻿using Newtonsoft.Json;
using System;
using System.Diagnostics;
using System.Net.Http;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace Edug
{
    public sealed partial class RankPage : Page
    {
        public RankPage()
        {
            this.InitializeComponent();  
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)//Gdy strona jest aktywna
        {
            setLanguage();
            Functions.Function.getInfo();//Aktualizuje informacje dot. zdobytych punktów przez agenta w belce na dole ekranu
            setAppBar();
            getLeaderBoard();
        }

        public async void getLeaderBoard()//Uzyskuje listę wszystkich osiągnięć agenta
        {
            try
            {
                using (HttpClient client = new HttpClient())//Utworzenie klienta http w celu obsługi adresu url
                {
                    string group = PassedData.group;//kryptonim gry
                    string link = @"http://www.edug.pl/_webservices/extra_leaderboards.php?idg=" + group;//Tworzenie adresu url
                    var uri = new Uri(link);//Inicjowanie nowej instacji klasy Uri z podanym adresem strony
                    client.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;//Sprawdzenie czy zaszła zmiana od ostatniego żądania do serwera od momentu wysłania zapytania
                    var Response = await client.GetAsync(uri);// Wysyła żądanie GET dla danego odnośnika URL
                    var statusCode = Response.StatusCode;//Rezultat i kod http
                    //Jeśli odpowiedź jest inna od Http 200
                    //wtedy metoda EnsureSuccessStatusCode wyrzuci wyjątek
                    Response.EnsureSuccessStatusCode();
                    var ResponseText1 = await Response.Content.ReadAsStringAsync();//Pobranie asynchronicznie odpowiedzi od webserwera
                    client.CancelPendingRequests();//Anulowanie wszelkich żądań do serwera
                    client.Dispose();//Zamknięcie klienta
                    getPosition(ResponseText1);//Uzyskiwanie listy z osiągnięciami agenta
                }
            }
            catch (Exception ex)//Przy pojawieniu się wyjątku, treść błędu jest wyświetlana w konsoli
            {
                Debug.WriteLine(ex);
            }
        }

        public void getPosition(string edata)//Segreguje osiągnięcia według kategorii
        {
            Classes.RootObject obj = JsonConvert.DeserializeObject<Classes.RootObject>(edata);// Przetworzenie pliku json do typu.NET
            int licznik = obj.extra_leaderboards.Count;//Liczba wszystkich osiągnięć
            for (int i = 0; i < licznik; i++)
            {
                var item = new Classes.Position();//Utworzenie obiektu jako nowej instacji klasy Position 
                string type = obj.extra_leaderboards[i].position.type;//Kategoria misji
                string idu = obj.extra_leaderboards[i].position.idu;//Identyfikator agenta
                string points = obj.extra_leaderboards[i].position.points;//Liczba zdobytych punktów
                switch (type)//Dodanie do listy według kategorii misji
                {
                    case "spec"://Do misji specjalnej
                        item.idu = idu;//Zapisanie do obiektu identyfikatora agenta
                        item.points = points;//Zapisanie do obiektu liczbę zdobytych punktów
                        speclist.Items.Add(item);//Dodanie obiektu do listy wyników dla misji specjalnej, gdzie zostanie wyświetlony
                        break;
                    case "labo"://Do misji laboratoryjnej
                        item.idu = idu;
                        item.points = points;
                        lablist.Items.Add(item);//Dodanie obiektu do listy wyników dla misji laboratoryjnej, gdzie zostanie wyświetlony
                        break;
                    case "fast"://Do misji błyskawicznej
                        item.idu = idu;
                        item.points = points;
                        fastlist.Items.Add(item);//Dodanie obiektu do listy wyników dla misji błyskawicznej, gdzie zostanie wyświetlony
                        break;
                    default://Do misji ostatecznej
                        item.idu = idu;
                        item.points = points;
                        alllist.Items.Add(item);//Dodanie obiektu do listy wyników dla misji ostatecznej, gdzie zostanie wyświetlony
                        break;
                }
            }
        }

        public void setLanguage()//Wyświetla tekst według języka agenta
        {
            switch (PassedData.lang)//Tekst na stronie jest wyświetlany w zależności od języka
            {
                case "pl"://W języku polskim
                    pivot_agentspec.Header = "Specjalny";
                    pivot_agentlab.Header = "Laboratoryjny";
                    pivot_agentfast.Header = "Błyskawiczny";
                    pivot_agentall.Header = "Wszechstronny";
                    backButton.Label = "Powrót";
                    logoutButton.Label = "Wyloguj";
                    break;
                case "en"://W języku angielskim
                    pivot_agentspec.Header = "Special";
                    pivot_agentlab.Header = "Lab";
                    pivot_agentfast.Header = "Fast";
                    pivot_agentall.Header = "Comprehensive";
                    backButton.Label = "Back";
                    logoutButton.Label = "Logout";
                    break;
            }
        }

        public void setAppBar()//Wyświetla tekst i wartość przycisków na belce w dolnej części ekranu
        {
            AvatarAddAppBarButton.Label = PassedData.count_avatar + PassedData.countAvatarString;//Tekst i ilość zdobytych avatarów
            BitcoinAddAppBarButton.Label = PassedData.count_bitcoin + PassedData.countBitcoinString;//Tekst i ilość zdobytych bitcoinów
            ExacoinAddAppBarButton.Label = PassedData.count_exacoin + PassedData.countExacoinString;//Tekst i ilość zdobytych exacoinów
            PointsAddAppBarButton.Label = PassedData.count_point + PassedData.countPointString;//Tekst i ilość zdobytych punktów
        }

        private void backButton_Click(object sender, RoutedEventArgs e)//Naciśnięcie przycisku powoduje powrót do poprzedniej strony
        {
            Frame.Navigate(typeof(MenuPage));//Przejście do poprzedniej strony, czyli do menu głównego
        }

        private async void logoutButton_Click(object sender, RoutedEventArgs e)//Naciśnięcie przycisku powoduje pojawienie się okna dialogowego z pytaniem o wylogowanie się z aplikacji
        {
            MessageDialog messageDialog = new MessageDialog(PassedData.askString);//Wyświetlenie treści komunikatu z pytaniem o wylogowanie się
            messageDialog.Commands.Add(new UICommand(PassedData.yesString, new UICommandInvokedHandler(CommandInvokedHandler)));//Dodanie przycisku z tekstem potwierdzający wylogowanie i obsługa po kliknięciu potwierdzającego wylogowanie
            messageDialog.Commands.Add(new UICommand(PassedData.noString));//Dodanie przycisku z tekstem anulujący wylogowanie się

            //Polecenie, które będzie wywołane jako potwierdzenie chęci wylogowania się z aplikacji 
            messageDialog.DefaultCommandIndex = 0;//Dla opcji obsługującej wylogowanie 

            //Polecenie, które będzie wywołane jako anulowanie chęci wylogowania się z aplikacji 
            messageDialog.CancelCommandIndex = 1;//Dla drugiej opcji anulującej wylogowanie

            //Wywołanie okna dialogowego
            await messageDialog.ShowAsync();
        }

        public void CommandInvokedHandler(IUICommand command)//Gdy użytkownik potwierdzi chęć wylogowania się z aplikacji
        {
            PassedData.LogOut = true;//Ustawienie flagi dla wylogowania użytkownika żeby wyświetlić komunikat o wylogowaniu się
            PassedData.isSelected = false;//Ustawienie domyślnej wartości flagi z wyborem motywu
            PassedData.chosenComboItem = null;////Ustawienie domyślnej wartości wybranego motywu
            PassedData.chosenTheme = "1";//Ustawienie domyślnej wartości motywu
            Frame.Navigate(typeof(MainPage));//Przeniesienie do strony logowania
        }
    }
}

