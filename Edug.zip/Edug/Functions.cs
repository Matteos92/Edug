﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using Windows.UI.Popups;

namespace Edug//klasa z funkcjami które są wykorzystywane przez wiele innych funkcji
{
    public class Functions
    {
        public static partial class Function
        {
            public static async void showMessage(string message)//Funkcja do wyświetlenia komunikatu na ekranie, jako wejście jest treść wiadomości do wyświetlenia
            {
                try
                {
                    MessageDialog msgbox = new MessageDialog(message);
                    await msgbox.ShowAsync();
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex);
                }
            }

            //źródło: https:/ /stackoverflow.com/a/30632338
            public static Tuple<string,string,string,string> Rearrange(string answer1, string answer2, string answer3, string answer4)
            {   
                List<string> rearrange = new List<string>();
                Random random = new Random();
                rearrange.Add(answer1);
                rearrange.Add(answer2);
                rearrange.Add(answer3);
                rearrange.Add(answer4);
                for (int i = rearrange.Count - 1; i >= 0; i--)
                {
                    string tmp = rearrange[i];
                    int randomIndex = random.Next(i + 1);
                    rearrange[i] = rearrange[randomIndex];
                    rearrange[randomIndex] = tmp;
                }
                var tuple = new Tuple<string, string, string, string>(rearrange[0].ToString(), rearrange[1].ToString(), rearrange[2].ToString(), rearrange[3].ToString());
                return tuple;
            }//Funkcja do sortowania losowo odpowiedzi przed wyświetleniem graczowi

            public static async void getInfo()//Funkcja do aktualizacji nt. zdobytych punktów przez agenta
            {
                try
                {
                    string url = PassedData.url;//odnośnik do pobrania informacji o punktach agenta
                    using (HttpClient httpClient = new HttpClient())
                    {
                        Uri uri = new Uri(url);
                        httpClient.DefaultRequestHeaders.IfModifiedSince = DateTimeOffset.Now;
                        var Response = await httpClient.GetAsync(uri);
                        var json = await Response.Content.ReadAsStringAsync();
                        httpClient.CancelPendingRequests();
                        httpClient.Dispose();
                        Classes.RootObject obj = JsonConvert.DeserializeObject<Classes.RootObject>(json);
                        string ResponseText = obj.user_account.result.ToString();
                        if (ResponseText.Equals("True"))
                        {
                            PassedData.count_bitcoin = obj.user_account.count_bitcoin.ToString();//liczba bitcoinów
                            PassedData.count_avatar = obj.user_account.count_avatar.ToString();//liczba avatarów
                            PassedData.count_exacoin = obj.user_account.count_exacoin.ToString();//liczba exacoinów
                            PassedData.count_mission = obj.user_account.count_mission.ToString();//liczba misji
                            PassedData.count_point = obj.user_account.count_point.ToString();//liczba zdobytych puntktów
                        }
                    }
                }
                catch (Exception ex)//Przy pojawieniu się wyjątku, treść błędu jest wyświetlana w konsoli
                {
                    Debug.WriteLine(ex);
                }
            }
        }
    }
}
